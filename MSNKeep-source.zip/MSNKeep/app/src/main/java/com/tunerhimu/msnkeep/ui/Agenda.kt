@file:OptIn(ExperimentalMaterial3Api::class)

package com.tunerhimu.msnkeep.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.tunerhimu.msnkeep.MainViewModel
import com.tunerhimu.msnkeep.data.Event

private sealed interface AgendaRow {
    data class Header(val text: String) : AgendaRow
    data class Entry(
        val key: String, val time: Long, val title: String, val sub: String,
        val isTask: Boolean, val id: Long
    ) : AgendaRow
}

@Composable
fun AgendaTab(vm: MainViewModel, onOpenTask: (Long) -> Unit, onOpenEvent: (Long) -> Unit) {
    val tasks by vm.tasks.collectAsStateWithLifecycle()
    val events by vm.events.collectAsStateWithLifecycle()
    val bn = LocalBn.current
    val today = tr("Today", "আজ")
    val tomorrow = tr("Tomorrow", "আগামীকাল")
    val taskLabel = tr("Task", "কাজ")
    val eventLabel = tr("Event", "ইভেন্ট")

    val rows = remember(tasks, events, bn) {
        val start = startOfDay(System.currentTimeMillis())
        val items = ArrayList<AgendaRow.Entry>()
        for (t in tasks) {
            val d = t.dueAt
            if (!t.done && d != null && d >= start) {
                items.add(AgendaRow.Entry("t" + t.id, d, t.title, fmtTime(d, bn), true, t.id))
            }
        }
        for (e in events) {
            if (e.endAt >= start) {
                val loc = if (e.location.isBlank()) "" else " • " + e.location
                items.add(
                    AgendaRow.Entry(
                        "e" + e.id, e.startAt, e.title,
                        fmtTime(e.startAt, bn) + " – " + fmtTime(e.endAt, bn) + loc,
                        false, e.id
                    )
                )
            }
        }
        items.sortBy { it.time }
        val out = ArrayList<AgendaRow>()
        var lastDay = -1L
        for (item in items) {
            val day = startOfDay(item.time)
            if (day != lastDay) {
                lastDay = day
                val diff = Math.round((day - start).toDouble() / DAY_MS.toDouble())
                val text = when (diff) {
                    0L -> today
                    1L -> tomorrow
                    else -> fmtDate(day, bn)
                }
                out.add(AgendaRow.Header(text))
            }
            out.add(item)
        }
        out
    }

    Column(Modifier.fillMaxSize()) {
        Text(
            tr("Agenda", "এজেন্ডা"),
            style = MaterialTheme.typography.headlineSmall,
            modifier = Modifier.padding(16.dp)
        )
        if (rows.isEmpty()) {
            Box(Modifier.fillMaxSize().padding(32.dp), contentAlignment = Alignment.Center) {
                Text(
                    tr("Nothing scheduled. Tap + to add an event.", "কিছু নির্ধারিত নেই। + চেপে ইভেন্ট যোগ করুন।"),
                    style = MaterialTheme.typography.bodyLarge
                )
            }
        } else {
            LazyColumn(
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 4.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(
                    rows,
                    key = { r ->
                        when (r) {
                            is AgendaRow.Header -> "h" + r.text
                            is AgendaRow.Entry -> r.key
                        }
                    }
                ) { r ->
                    when (r) {
                        is AgendaRow.Header -> Text(
                            r.text,
                            style = MaterialTheme.typography.titleSmall,
                            color = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.padding(top = 8.dp)
                        )
                        is AgendaRow.Entry -> Card(
                            onClick = { if (r.isTask) onOpenTask(r.id) else onOpenEvent(r.id) },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f)) {
                                    Text(r.title, fontWeight = FontWeight.SemiBold)
                                    Text(r.sub, style = MaterialTheme.typography.bodySmall)
                                }
                                Text(
                                    if (r.isTask) taskLabel else eventLabel,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun EventEditorScreen(vm: MainViewModel, eventId: Long, onBack: () -> Unit) {
    var existing by remember { mutableStateOf<Event?>(null) }
    var ready by remember { mutableStateOf(false) }
    LaunchedEffect(eventId) {
        existing = if (eventId == 0L) null else vm.loadEvent(eventId)
        ready = true
    }
    if (!ready) Box(Modifier.fillMaxSize()) else EventEditorContent(vm, existing, onBack)
}

@Composable
private fun EventEditorContent(vm: MainViewModel, existing: Event?, onBack: () -> Unit) {
    val first = nextHour()
    val base = existing ?: Event(startAt = first, endAt = first + 3_600_000L)
    var title by remember { mutableStateOf(base.title) }
    var desc by remember { mutableStateOf(base.description) }
    var location by remember { mutableStateOf(base.location) }
    var start by remember { mutableStateOf(base.startAt) }
    var end by remember { mutableStateOf(base.endAt) }
    var repeat by remember { mutableStateOf(base.repeatMode) }
    var alerts by remember { mutableStateOf(base.alerts) }
    var confirmDelete by remember { mutableStateOf(false) }
    val untitled = tr("Untitled event", "শিরোনামহীন ইভেন্ট")

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(if (existing == null) tr("New event", "নতুন ইভেন্ট") else tr("Edit event", "ইভেন্ট সম্পাদনা")) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = null)
                    }
                },
                actions = {
                    if (existing != null) {
                        IconButton(onClick = { confirmDelete = true }) {
                            Icon(Icons.Default.Delete, contentDescription = null)
                        }
                    }
                }
            )
        }
    ) { pad ->
        Column(
            Modifier.padding(pad).fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            OutlinedTextField(
                value = title, onValueChange = { title = it },
                modifier = Modifier.fillMaxWidth(),
                label = { Text(tr("Title", "শিরোনাম")) }
            )
            OutlinedTextField(
                value = location, onValueChange = { location = it },
                modifier = Modifier.fillMaxWidth(), singleLine = true,
                label = { Text(tr("Location", "স্থান")) }
            )
            OutlinedTextField(
                value = desc, onValueChange = { desc = it },
                modifier = Modifier.fillMaxWidth(), minLines = 2,
                label = { Text(tr("Description", "বিবরণ")) }
            )
            DateTimeField(
                label = tr("Starts", "শুরু"), value = start, clearable = false,
                onChange = { v ->
                    if (v != null) {
                        val length = end - start
                        start = v
                        end = v + (if (length > 0) length else 3_600_000L)
                    }
                }
            )
            DateTimeField(
                label = tr("Ends", "শেষ"), value = end, clearable = false,
                onChange = { v ->
                    if (v != null) end = if (v < start) start else v
                }
            )
            RepeatChips(value = repeat, onChange = { repeat = it })
            AlertChips(value = alerts, onChange = { alerts = it })
            Button(
                onClick = {
                    vm.saveEvent(
                        base.copy(
                            title = title.trim().ifBlank { untitled },
                            description = desc, location = location.trim(),
                            startAt = start, endAt = end, repeatMode = repeat, alerts = alerts
                        )
                    )
                    onBack()
                },
                modifier = Modifier.fillMaxWidth()
            ) { Text(tr("Save", "সংরক্ষণ")) }
        }
    }

    if (confirmDelete) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            title = { Text(tr("Delete event?", "ইভেন্টটি মুছবেন?")) },
            confirmButton = {
                TextButton(onClick = {
                    confirmDelete = false
                    vm.deleteEvent(base.id)
                    onBack()
                }) { Text(tr("Delete", "মুছুন"), color = MaterialTheme.colorScheme.error) }
            },
            dismissButton = {
                TextButton(onClick = { confirmDelete = false }) { Text(tr("Cancel", "বাতিল")) }
            }
        )
    }
}
