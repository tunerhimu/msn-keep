package com.tunerhimu.msnkeep.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

val LocalBn = compositionLocalOf { true }

@Composable
fun tr(en: String, bn: String): String = if (LocalBn.current) bn else en

private val LightScheme = lightColorScheme(
    primary = Color(0xFF00796B),
    onPrimary = Color.White,
    primaryContainer = Color(0xFFB2EBE0),
    onPrimaryContainer = Color(0xFF00201B),
    secondary = Color(0xFF4A6360),
    secondaryContainer = Color(0xFFCCE8E3),
    onSecondaryContainer = Color(0xFF05201C),
    tertiary = Color(0xFF8A5A00),
    tertiaryContainer = Color(0xFFFFDDB3),
    onTertiaryContainer = Color(0xFF2C1700),
    background = Color(0xFFF4F9F7),
    onBackground = Color(0xFF161D1B),
    surface = Color(0xFFFFFFFF),
    onSurface = Color(0xFF161D1B),
    surfaceVariant = Color(0xFFE3EDE9),
    onSurfaceVariant = Color(0xFF3F4946),
    outline = Color(0xFF6F7976),
    outlineVariant = Color(0xFFBFC9C5)
)

private val DarkScheme = darkColorScheme(
    primary = Color(0xFF4DB6A3),
    onPrimary = Color(0xFF003730),
    primaryContainer = Color(0xFF005047),
    onPrimaryContainer = Color(0xFFB2EBE0),
    secondary = Color(0xFFB1CCC7),
    secondaryContainer = Color(0xFF334B47),
    onSecondaryContainer = Color(0xFFCCE8E3),
    tertiary = Color(0xFFFFB955),
    tertiaryContainer = Color(0xFF633F00),
    onTertiaryContainer = Color(0xFFFFDDB3),
    background = Color(0xFF0E1513),
    onBackground = Color(0xFFDDE4E1),
    surface = Color(0xFF16201D),
    onSurface = Color(0xFFDDE4E1),
    surfaceVariant = Color(0xFF2B3633),
    onSurfaceVariant = Color(0xFFBEC9C5),
    outline = Color(0xFF899390),
    outlineVariant = Color(0xFF3F4946)
)

private val AppShapes = Shapes(
    small = RoundedCornerShape(12.dp),
    medium = RoundedCornerShape(18.dp),
    large = RoundedCornerShape(24.dp),
    extraLarge = RoundedCornerShape(32.dp)
)

private val AppTypography = Typography(
    headlineMedium = TextStyle(fontWeight = FontWeight.Bold, fontSize = 28.sp, lineHeight = 36.sp),
    headlineSmall = TextStyle(fontWeight = FontWeight.Bold, fontSize = 24.sp, lineHeight = 32.sp),
    titleLarge = TextStyle(fontWeight = FontWeight.Bold, fontSize = 21.sp, lineHeight = 28.sp),
    titleMedium = TextStyle(fontWeight = FontWeight.SemiBold, fontSize = 16.sp, lineHeight = 24.sp)
)

@Composable
fun MSNKeepTheme(themeMode: Int, content: @Composable () -> Unit) {
    val dark = when (themeMode) {
        1 -> false
        2 -> true
        else -> isSystemInDarkTheme()
    }
    MaterialTheme(
        colorScheme = if (dark) DarkScheme else LightScheme,
        shapes = AppShapes,
        typography = AppTypography,
        content = content
    )
}

// Index 0 = default color. Indexes 1..7 = colors.
val Accent = listOf(
    Color(0xFF9E9E9E), Color(0xFFF9A825), Color(0xFFF4511E), Color(0xFFD81B60),
    Color(0xFF8E24AA), Color(0xFF1E88E5), Color(0xFF43A047), Color(0xFF6D4C41)
)
private val PaletteLight = listOf(
    Color.Unspecified, Color(0xFFFFF4B8), Color(0xFFFFD6C7), Color(0xFFFAC6DA),
    Color(0xFFE6C9EE), Color(0xFFC3E0FB), Color(0xFFCDEBCF), Color(0xFFDDD2CD)
)
private val PaletteDark = listOf(
    Color.Unspecified, Color(0xFF4D4A1F), Color(0xFF5A3A2E), Color(0xFF5A2E40),
    Color(0xFF45305A), Color(0xFF2E4A66), Color(0xFF2E5A3A), Color(0xFF4E403A)
)

@Composable
fun isDarkNow(): Boolean = MaterialTheme.colorScheme.background.luminance() < 0.5f

@Composable
fun noteBg(i: Int): Color {
    if (i <= 0 || i >= PaletteLight.size) return MaterialTheme.colorScheme.surface
    return if (isDarkNow()) PaletteDark[i] else PaletteLight[i]
}

@Composable
fun noteFg(i: Int): Color {
    if (i <= 0 || i >= PaletteLight.size) return MaterialTheme.colorScheme.onSurface
    return if (isDarkNow()) Color(0xFFECECEC) else Color(0xFF1C1B1F)
}
