package com.tunerhimu.msnkeep.ui

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.platform.LocalContext

val LocalBn = compositionLocalOf { true }

@Composable
fun tr(en: String, bn: String): String = if (LocalBn.current) bn else en

private val LightScheme = lightColorScheme(
    primary = Color(0xFF1E6F5C),
    secondary = Color(0xFF4A635C),
    tertiary = Color(0xFF3F6374)
)
private val DarkScheme = darkColorScheme(
    primary = Color(0xFF7DD6BC),
    secondary = Color(0xFFB1CCC3),
    tertiary = Color(0xFFA6CBE0)
)

@Composable
fun MSNKeepTheme(themeMode: Int, content: @Composable () -> Unit) {
    val dark = when (themeMode) {
        1 -> false
        2 -> true
        else -> isSystemInDarkTheme()
    }
    val ctx = LocalContext.current
    val scheme = if (Build.VERSION.SDK_INT >= 31) {
        if (dark) dynamicDarkColorScheme(ctx) else dynamicLightColorScheme(ctx)
    } else {
        if (dark) DarkScheme else LightScheme
    }
    MaterialTheme(colorScheme = scheme, content = content)
}

// Index 0 = default color. Indexes 1..7 = colors.
val Accent = listOf(
    Color(0xFF9E9E9E), Color(0xFFF9A825), Color(0xFFF4511E), Color(0xFFD81B60),
    Color(0xFF8E24AA), Color(0xFF1E88E5), Color(0xFF43A047), Color(0xFF6D4C41)
)
private val PaletteLight = listOf(
    Color.Unspecified, Color(0xFFFFF9C4), Color(0xFFFFCCBC), Color(0xFFF8BBD0),
    Color(0xFFE1BEE7), Color(0xFFBBDEFB), Color(0xFFC8E6C9), Color(0xFFD7CCC8)
)
private val PaletteDark = listOf(
    Color.Unspecified, Color(0xFF4D4A1F), Color(0xFF5A3A2E), Color(0xFF5A2E40),
    Color(0xFF45305A), Color(0xFF2E4A66), Color(0xFF2E5A3A), Color(0xFF4E403A)
)

@Composable
fun isDarkNow(): Boolean = MaterialTheme.colorScheme.background.luminance() < 0.5f

@Composable
fun noteBg(i: Int): Color {
    if (i <= 0 || i >= PaletteLight.size) return MaterialTheme.colorScheme.surfaceVariant
    return if (isDarkNow()) PaletteDark[i] else PaletteLight[i]
}

@Composable
fun noteFg(i: Int): Color {
    if (i <= 0 || i >= PaletteLight.size) return MaterialTheme.colorScheme.onSurfaceVariant
    return if (isDarkNow()) Color(0xFFECECEC) else Color(0xFF1C1B1F)
}
