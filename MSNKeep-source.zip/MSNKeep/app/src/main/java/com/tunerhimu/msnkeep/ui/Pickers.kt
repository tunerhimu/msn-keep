package com.tunerhimu.msnkeep.ui

import android.app.DatePickerDialog
import android.app.TimePickerDialog
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.tunerhimu.msnkeep.reminder.ReminderScheduler
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

const val DAY_MS = 86_400_000L

fun localeFor(bn: Boolean): Locale = if (bn) Locale("bn", "BD") else Locale.getDefault()

fun fmtDate(ms: Long, bn: Boolean): String =
    SimpleDateFormat("EEE, d MMM yyyy", localeFor(bn)).format(Date(ms))

fun fmtTime(ms: Long, bn: Boolean): String =
    SimpleDateFormat("hh:mm a", localeFor(bn)).format(Date(ms))

fun startOfDay(ms: Long): Long {
    val c = Calendar.getInstance()
    c.timeInMillis = ms
    c.set(Calendar.HOUR_OF_DAY, 0)
    c.set(Calendar.MINUTE, 0)
    c.set(Calendar.SECOND, 0)
    c.set(Calendar.MILLISECOND, 0)
    return c.timeInMillis
}

fun nextHour(): Long {
    val c = Calendar.getInstance()
    c.add(Calendar.HOUR_OF_DAY, 1)
    c.set(Calendar.MINUTE, 0)
    c.set(Calendar.SECOND, 0)
    c.set(Calendar.MILLISECOND, 0)
    return c.timeInMillis
}

fun beforeLabel(min: Int, bn: Boolean): String = when {
    min == 0 -> if (bn) "ঠিক সময়ে" else "At time"
    min == 1440 -> if (bn) "১ দিন আগে" else "1 day before"
    min == 60 -> if (bn) "১ ঘণ্টা আগে" else "1 hour before"
    else -> if (bn) "$min মিনিট আগে" else "$min min before"
}

@Composable
fun DateTimeField(label: String, value: Long?, clearable: Boolean, onChange: (Long?) -> Unit) {
    val ctx = LocalContext.current
    val bn = LocalBn.current
    val noDate = tr("Pick date", "তারিখ বাছুন")
    val noTime = tr("Pick time", "সময় বাছুন")

    fun calOf(): Calendar {
        val c = Calendar.getInstance()
        c.timeInMillis = value ?: nextHour()
        return c
    }

    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text(label, style = MaterialTheme.typography.labelLarge)
        Row(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedButton(onClick = {
                val c = calOf()
                DatePickerDialog(
                    ctx,
                    DatePickerDialog.OnDateSetListener { _, y, m, d ->
                        val n = calOf()
                        n.set(y, m, d)
                        onChange(n.timeInMillis)
                    },
                    c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH)
                ).show()
            }) { Text(if (value == null) noDate else fmtDate(value, bn)) }

            OutlinedButton(onClick = {
                val c = calOf()
                TimePickerDialog(
                    ctx,
                    TimePickerDialog.OnTimeSetListener { _, h, min ->
                        val n = calOf()
                        n.set(Calendar.HOUR_OF_DAY, h)
                        n.set(Calendar.MINUTE, min)
                        n.set(Calendar.SECOND, 0)
                        n.set(Calendar.MILLISECOND, 0)
                        onChange(n.timeInMillis)
                    },
                    c.get(Calendar.HOUR_OF_DAY), c.get(Calendar.MINUTE), false
                ).show()
            }) { Text(if (value == null) noTime else fmtTime(value, bn)) }

            if (clearable && value != null) {
                IconButton(onClick = { onChange(null) }) {
                    Icon(Icons.Default.Close, contentDescription = null)
                }
            }
        }
    }
}

@Composable
fun AlertChips(value: String, onChange: (String) -> Unit) {
    val bn = LocalBn.current
    val selected = ReminderScheduler.parseAlerts(value)
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text(
            tr("Reminders (up to 3)", "রিমাইন্ডার (সর্বোচ্চ ৩টি)"),
            style = MaterialTheme.typography.labelLarge
        )
        Row(
            Modifier.horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            for (m in listOf(0, 5, 10, 30, 60, 1440)) {
                FilterChip(
                    selected = m in selected,
                    onClick = {
                        val next = if (m in selected) selected - m
                        else if (selected.size < 3) selected + m
                        else selected
                        onChange(next.sortedDescending().joinToString(","))
                    },
                    label = { Text(beforeLabel(m, bn)) }
                )
            }
        }
    }
}

@Composable
fun RepeatChips(value: Int, onChange: (Int) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text(tr("Repeat", "পুনরাবৃত্তি"), style = MaterialTheme.typography.labelLarge)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = value == 0, onClick = { onChange(0) }, label = { Text(tr("None", "নেই")) })
            FilterChip(selected = value == 1, onClick = { onChange(1) }, label = { Text(tr("Daily", "প্রতিদিন")) })
            FilterChip(selected = value == 2, onClick = { onChange(2) }, label = { Text(tr("Weekly", "প্রতি সপ্তাহে")) })
        }
    }
}
