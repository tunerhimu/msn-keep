package com.tunerhimu.msnkeep.reminder

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import com.tunerhimu.msnkeep.data.AppDatabase
import com.tunerhimu.msnkeep.data.Event
import com.tunerhimu.msnkeep.data.Task
import java.util.Calendar

object ReminderScheduler {
    const val KIND_TASK = "task"
    const val KIND_EVENT = "event"
    const val KIND_TEST = "test"
    private const val SLOTS = 3
    private const val FLAGS = PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE

    fun parseAlerts(s: String): List<Int> =
        s.split(",").mapNotNull { it.trim().toIntOrNull() }.distinct().sortedDescending().take(SLOTS)

    private fun requestCode(kind: Int, id: Long, idx: Int): Int =
        (((kind * 1_000_000L) + id) * 4 + idx).toInt()

    private fun alarmManager(ctx: Context): AlarmManager =
        ctx.getSystemService(AlarmManager::class.java)

    fun canScheduleExact(ctx: Context): Boolean =
        Build.VERSION.SDK_INT < 31 || alarmManager(ctx).canScheduleExactAlarms()

    private fun cancel(ctx: Context, kind: Int, id: Long) {
        val am = alarmManager(ctx)
        for (idx in 0 until SLOTS) {
            val pi = PendingIntent.getBroadcast(
                ctx, requestCode(kind, id, idx),
                Intent(ctx, AlarmReceiver::class.java),
                PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE
            )
            if (pi != null) {
                am.cancel(pi)
                pi.cancel()
            }
        }
    }

    private fun setAlarm(ctx: Context, at: Long, pi: PendingIntent) {
        val am = alarmManager(ctx)
        try {
            if (canScheduleExact(ctx)) {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
            } else {
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
            }
        } catch (e: SecurityException) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
        }
    }

    private fun buildIntent(
        ctx: Context, kind: String, id: Long, title: String, desc: String,
        minutes: Int, notifId: Int, snoozed: Boolean
    ): Intent = Intent(ctx, AlarmReceiver::class.java).apply {
        putExtra("kind", kind)
        putExtra("id", id)
        putExtra("title", title)
        putExtra("desc", desc)
        putExtra("minutes", minutes)
        putExtra("notifId", notifId)
        putExtra("snoozed", snoozed)
    }

    private fun scheduleSlots(
        ctx: Context, kindInt: Int, kind: String, id: Long,
        title: String, desc: String, whenMs: Long, alerts: String
    ) {
        cancel(ctx, kindInt, id)
        val now = System.currentTimeMillis()
        parseAlerts(alerts).forEachIndexed { idx, min ->
            val at = whenMs - min * 60_000L
            if (at > now) {
                val code = requestCode(kindInt, id, idx)
                val pi = PendingIntent.getBroadcast(
                    ctx, code, buildIntent(ctx, kind, id, title, desc, min, code, false), FLAGS
                )
                setAlarm(ctx, at, pi)
            }
        }
    }

    fun scheduleTask(ctx: Context, t: Task) {
        val due = t.dueAt
        if (due == null || t.done) {
            cancel(ctx, 1, t.id)
            return
        }
        scheduleSlots(ctx, 1, KIND_TASK, t.id, t.title, t.description, due, t.alerts)
    }

    fun scheduleEvent(ctx: Context, e: Event) {
        val info = if (e.location.isBlank()) e.description else e.location
        scheduleSlots(ctx, 2, KIND_EVENT, e.id, e.title, info, e.startAt, e.alerts)
    }

    fun cancelTask(ctx: Context, id: Long) = cancel(ctx, 1, id)

    fun cancelEvent(ctx: Context, id: Long) = cancel(ctx, 2, id)

    fun scheduleTest(ctx: Context, seconds: Int) {
        val pi = PendingIntent.getBroadcast(
            ctx, 999_999_990, buildIntent(ctx, KIND_TEST, 0, "MSN Keep", "", 0, 4242, false), FLAGS
        )
        setAlarm(ctx, System.currentTimeMillis() + seconds * 1000L, pi)
    }

    fun scheduleSnooze(
        ctx: Context, kind: String, id: Long, title: String, desc: String, minutes: Int, notifId: Int
    ) {
        val pi = PendingIntent.getBroadcast(
            ctx, 700_000_000 + notifId,
            buildIntent(ctx, kind, id, title, desc, minutes, notifId, true), FLAGS
        )
        setAlarm(ctx, System.currentTimeMillis() + 10 * 60_000L, pi)
    }

    private fun period(cal: Calendar, mode: Int) {
        cal.add(Calendar.DAY_OF_YEAR, if (mode == 1) 1 else 7)
    }

    private fun catchUp(ms: Long, mode: Int, now: Long): Long {
        val cal = Calendar.getInstance().apply { timeInMillis = ms }
        var n = 0
        while (cal.timeInMillis < now && n < 4000) {
            period(cal, mode)
            n++
        }
        return cal.timeInMillis
    }

    private fun nextOccurrence(ms: Long, mode: Int, now: Long): Long {
        val cal = Calendar.getInstance().apply { timeInMillis = ms }
        period(cal, mode)
        return catchUp(cal.timeInMillis, mode, now)
    }

    /** Re-creates all alarms (after reboot, app update, app start, or an alarm firing). */
    suspend fun rescheduleAll(ctx: Context) {
        val dao = AppDatabase.get(ctx).dao()
        val now = System.currentTimeMillis()
        for (t in dao.tasksOnce()) {
            var task = t
            val due = t.dueAt
            if (due != null && !t.done && t.repeatMode != 0 && due < now) {
                task = t.copy(dueAt = catchUp(due, t.repeatMode, now))
                dao.upsertTask(task)
            }
            scheduleTask(ctx, task)
        }
        for (e in dao.eventsOnce()) {
            var ev = e
            if (e.repeatMode != 0 && e.endAt < now) {
                val len = e.endAt - e.startAt
                val newStart = catchUp(e.startAt, e.repeatMode, now - len)
                ev = e.copy(startAt = newStart, endAt = newStart + len)
                dao.upsertEvent(ev)
            }
            scheduleEvent(ctx, ev)
        }
    }

    /** Checks a task done, or reopens it. Repeating tasks roll forward to the next date instead. */
    suspend fun toggleDone(ctx: Context, t: Task) {
        val dao = AppDatabase.get(ctx).dao()
        val now = System.currentTimeMillis()
        val due = t.dueAt
        val updated = if (t.done) {
            t.copy(done = false, completedAt = null)
        } else if (t.repeatMode != 0 && due != null) {
            t.copy(dueAt = nextOccurrence(due, t.repeatMode, now))
        } else {
            t.copy(done = true, completedAt = now)
        }
        dao.upsertTask(updated)
        scheduleTask(ctx, updated)
    }
}
