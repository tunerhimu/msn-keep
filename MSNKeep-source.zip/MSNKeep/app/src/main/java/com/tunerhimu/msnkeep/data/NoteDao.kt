package com.tunerhimu.msnkeep.data

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface NoteDao {
    @Query("SELECT * FROM notes WHERE deleted = 0 ORDER BY pinned DESC, updatedAt DESC")
    fun activeNotes(): Flow<List<Note>>

    @Query("SELECT * FROM notes WHERE deleted = 1 ORDER BY updatedAt DESC")
    fun trashedNotes(): Flow<List<Note>>

    @Query("SELECT * FROM notes WHERE id = :id")
    suspend fun getNote(id: Long): Note?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(note: Note): Long

    @Query("UPDATE notes SET deleted = :deleted, updatedAt = :time WHERE id = :id")
    suspend fun setDeleted(id: Long, deleted: Boolean, time: Long)

    @Query("DELETE FROM notes WHERE id = :id")
    suspend fun deleteForever(id: Long)

    @Query("DELETE FROM notes WHERE deleted = 1")
    suspend fun emptyTrash()

    @Query("UPDATE notes SET categoryId = NULL WHERE categoryId = :categoryId")
    suspend fun clearCategory(categoryId: Long)

    @Query("SELECT * FROM categories ORDER BY name COLLATE NOCASE")
    fun categories(): Flow<List<Category>>

    @Insert
    suspend fun insertCategory(category: Category): Long

    @Update
    suspend fun updateCategory(category: Category)

    @Delete
    suspend fun deleteCategory(category: Category)

    @Query("SELECT * FROM tasks ORDER BY done ASC, CASE WHEN dueAt IS NULL THEN 1 ELSE 0 END, dueAt ASC")
    fun tasks(): Flow<List<Task>>

    @Query("SELECT * FROM tasks")
    suspend fun tasksOnce(): List<Task>

    @Query("SELECT * FROM tasks WHERE id = :id")
    suspend fun getTask(id: Long): Task?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertTask(task: Task): Long

    @Query("DELETE FROM tasks WHERE id = :id")
    suspend fun deleteTask(id: Long)

    @Query("SELECT * FROM events ORDER BY startAt ASC")
    fun events(): Flow<List<Event>>

    @Query("SELECT * FROM events")
    suspend fun eventsOnce(): List<Event>

    @Query("SELECT * FROM events WHERE id = :id")
    suspend fun getEvent(id: Long): Event?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertEvent(event: Event): Long

    @Query("DELETE FROM events WHERE id = :id")
    suspend fun deleteEvent(id: Long)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertVersion(v: NoteVersion): Long

    @Query("SELECT * FROM note_versions WHERE noteId = :noteId ORDER BY savedAt DESC")
    fun versions(noteId: Long): Flow<List<NoteVersion>>

    @Query("SELECT * FROM note_versions WHERE noteId = :noteId ORDER BY savedAt DESC")
    suspend fun versionsOnce(noteId: Long): List<NoteVersion>

    @Query("SELECT * FROM note_versions")
    suspend fun allVersions(): List<NoteVersion>

    @Query("DELETE FROM note_versions WHERE id = :id")
    suspend fun deleteVersion(id: Long)

    @Query("DELETE FROM note_versions WHERE noteId = :noteId")
    suspend fun deleteVersionsOf(noteId: Long)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAttachment(a: Attachment): Long

    @Query("SELECT * FROM attachments WHERE noteId = :noteId ORDER BY id")
    fun attachments(noteId: Long): Flow<List<Attachment>>

    @Query("SELECT * FROM attachments WHERE noteId = :noteId")
    suspend fun attachmentsOnce(noteId: Long): List<Attachment>

    @Query("SELECT * FROM attachments")
    suspend fun allAttachments(): List<Attachment>

    @Query("DELETE FROM attachments WHERE id = :id")
    suspend fun deleteAttachment(id: Long)

    @Query("DELETE FROM attachments WHERE noteId = :noteId")
    suspend fun deleteAttachmentsOf(noteId: Long)

    @Query("SELECT * FROM notes")
    suspend fun allNotesOnce(): List<Note>

    @Query("SELECT * FROM categories")
    suspend fun categoriesOnce(): List<Category>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertCategory(c: Category): Long

    @Query("DELETE FROM notes")
    suspend fun clearNotes()

    @Query("DELETE FROM categories")
    suspend fun clearCategories()

    @Query("DELETE FROM tasks")
    suspend fun clearTasks()

    @Query("DELETE FROM events")
    suspend fun clearEvents()

    @Query("DELETE FROM note_versions")
    suspend fun clearVersions()

    @Query("DELETE FROM attachments")
    suspend fun clearAttachments()
}
