package com.tunerhimu.msnkeep

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.tunerhimu.msnkeep.reminder.Notifier
import com.tunerhimu.msnkeep.reminder.ReminderScheduler
import com.tunerhimu.msnkeep.ui.AppNav
import com.tunerhimu.msnkeep.ui.LocalBn
import com.tunerhimu.msnkeep.ui.MSNKeepTheme
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    private val vm: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Notifier.ensureChannel(this)
        val appCtx = applicationContext
        CoroutineScope(Dispatchers.IO).launch { ReminderScheduler.rescheduleAll(appCtx) }

        setContent {
            val themeMode by vm.themeMode.collectAsStateWithLifecycle()
            val bn by vm.bengali.collectAsStateWithLifecycle()
            val permissionLauncher = rememberLauncherForActivityResult(
                ActivityResultContracts.RequestPermission()
            ) { }
            LaunchedEffect(Unit) {
                if (Build.VERSION.SDK_INT >= 33 &&
                    checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
                ) {
                    permissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                }
            }
            MSNKeepTheme(themeMode) {
                CompositionLocalProvider(LocalBn provides bn) {
                    AppNav(vm)
                }
            }
        }
    }
}
