package com.tunerhimu.msnkeep

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.tunerhimu.msnkeep.ui.AppNav
import com.tunerhimu.msnkeep.ui.LocalBn
import com.tunerhimu.msnkeep.ui.MSNKeepTheme

class MainActivity : ComponentActivity() {
    private val vm: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val themeMode by vm.themeMode.collectAsStateWithLifecycle()
            val bn by vm.bengali.collectAsStateWithLifecycle()
            MSNKeepTheme(themeMode) {
                CompositionLocalProvider(LocalBn provides bn) {
                    AppNav(vm)
                }
            }
        }
    }
}
