package com.tunerhimu.msnkeep.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.preferencesDataStore

val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "settings")

object SettingKeys {
    val THEME = intPreferencesKey("theme")
    val BN = booleanPreferencesKey("bengali")
    val GRID = booleanPreferencesKey("grid")
}
