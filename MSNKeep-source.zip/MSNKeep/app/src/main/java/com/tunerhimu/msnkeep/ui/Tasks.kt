@file:OptIn(ExperimentalMaterial3Api::class)

package com.tunerhimu.msnkeep.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.Checkbox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.tunerhimu.msnkeep.MainViewModel
import com.tunerhimu.msnkeep.data.Task

private fun priorityColor(p: Int): Color = when (p) {
    2 -> Color(0xFFE53935)
    1 -> Color(0xFFF9A825)
    else -> Color(0xFF9E9E9E)
}

@Composable
fun TasksTab(vm: MainViewModel, onOpen: (Long) -> Unit) {
    val tasks by vm.tasks.collectAsStateWithLifecycle()
    var showDone by remember { mutableStateOf(false) }
    val bn = LocalBn.current
    val now = System.currentTimeMillis()
    val pending = tasks.filter { !it.done }
    val done = tasks.filter { it.done }.sortedByDescending { it.completedAt ?: 0L }
    val list = if (showDone) done else pending

    Column(Modifier.fillMaxSize()) {
        Text(
            tr("Tasks & Reminders", "কাজ ও রিমাইন্ডার"),
            style = MaterialTheme.typography.headlineSmall,
            modifier = Modifier.padding(16.dp)
        )
        Row(
            Modifier.padding(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            FilterChip(
                selected = !showDone, onClick = { showDone = false },
                label = { Text(tr("Pending (${pending.size})", "বাকি (${pending.size})")) }
            )
            FilterChip(
                selected = showDone, onClick = { showDone = true },
                label = { Text(tr("Completed (${done.size})", "সম্পন্ন (${done.size})")) }
            )
        }
        if (list.isEmpty()) {
            Box(Modifier.fillMaxSize().padding(32.dp), contentAlignment = Alignment.Center) {
                Text(
                    if (showDone) tr("No completed tasks yet.", "এখনো কোনো কাজ সম্পন্ন হয়নি।")
                    else tr("No tasks. Tap + to add a task or reminder.", "কোনো কাজ নেই। + চেপে কাজ বা রিমাইন্ডার যোগ করুন।"),
                    style = MaterialTheme.typography.bodyLarge
                )
            }
        } else {
            LazyColumn(
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(list, key = { it.id }) { t ->
                    val due = t.dueAt
                    val overdue = due != null && due < now && !t.done
                    Card(onClick = { onOpen(t.id) }, modifier = Modifier.fillMaxWidth()) {
                        Row(
                            Modifier.padding(horizontal = 8.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Checkbox(checked = t.done, onCheckedChange = { vm.toggleTask(t) })
                            Column(Modifier.weight(1f)) {
                                Text(
                                    t.title,
                                    fontWeight = FontWeight.SemiBold,
                                    maxLines = 2,
                                    overflow = TextOverflow.Ellipsis,
                                    textDecoration = if (t.done) TextDecoration.LineThrough else TextDecoration.None
                                )
                                if (due != null) {
                                    val rep = if (t.repeatMode != 0) "  ↻" else ""
                                    Text(
                                        fmtDate(due, bn) + " • " + fmtTime(due, bn) + rep,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = if (overdue) MaterialTheme.colorScheme.error
                                        else MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                            Box(Modifier.size(12.dp).background(priorityColor(t.priority), CircleShape))
                            Spacer(Modifier.width(8.dp))
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun TaskEditorScreen(vm: MainViewModel, taskId: Long, onBack: () -> Unit) {
    var existing by remember { mutableStateOf<Task?>(null) }
    var ready by remember { mutableStateOf(false) }
    LaunchedEffect(taskId) {
        existing = if (taskId == 0L) null else vm.loadTask(taskId)
        ready = true
    }
    if (!ready) Box(Modifier.fillMaxSize()) else TaskEditorContent(vm, existing, onBack)
}

@Composable
private fun TaskEditorContent(vm: MainViewModel, existing: Task?, onBack: () -> Unit) {
    val base = existing ?: Task(dueAt = nextHour())
    var title by remember { mutableStateOf(base.title) }
    var desc by remember { mutableStateOf(base.description) }
    var due by remember { mutableStateOf(base.dueAt) }
    var priority by remember { mutableStateOf(base.priority) }
    var repeat by remember { mutableStateOf(base.repeatMode) }
    var alerts by remember { mutableStateOf(base.alerts) }
    var confirmDelete by remember { mutableStateOf(false) }
    val untitled = tr("Untitled task", "শিরোনামহীন কাজ")

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(if (existing == null) tr("New task", "নতুন কাজ") else tr("Edit task", "কাজ সম্পাদনা")) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = null)
                    }
                },
                actions = {
                    if (existing != null) {
                        IconButton(onClick = { confirmDelete = true }) {
                            Icon(Icons.Default.Delete, contentDescription = null)
                        }
                    }
                }
            )
        }
    ) { pad ->
        Column(
            Modifier.padding(pad).fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            OutlinedTextField(
                value = title, onValueChange = { title = it },
                modifier = Modifier.fillMaxWidth(),
                label = { Text(tr("Title", "শিরোনাম")) }
            )
            OutlinedTextField(
                value = desc, onValueChange = { desc = it },
                modifier = Modifier.fillMaxWidth(), minLines = 2,
                label = { Text(tr("Description", "বিবরণ")) }
            )
            DateTimeField(
                label = tr("Due date & time", "শেষ তারিখ ও সময়"),
                value = due, clearable = true, onChange = { due = it }
            )
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(tr("Priority", "অগ্রাধিকার"), style = MaterialTheme.typography.labelLarge)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(selected = priority == 0, onClick = { priority = 0 }, label = { Text(tr("Low", "কম")) })
                    FilterChip(selected = priority == 1, onClick = { priority = 1 }, label = { Text(tr("Medium", "মাঝারি")) })
                    FilterChip(selected = priority == 2, onClick = { priority = 2 }, label = { Text(tr("High", "বেশি")) })
                }
            }
            RepeatChips(value = repeat, onChange = { repeat = it })
            if (due != null) {
                AlertChips(value = alerts, onChange = { alerts = it })
            } else {
                Text(
                    tr("Set a due date and time to get reminders.", "রিমাইন্ডার পেতে তারিখ ও সময় ঠিক করুন।"),
                    style = MaterialTheme.typography.bodySmall
                )
            }
            Button(
                onClick = {
                    vm.saveTask(
                        base.copy(
                            title = title.trim().ifBlank { untitled },
                            description = desc, dueAt = due, priority = priority,
                            repeatMode = repeat, alerts = alerts
                        )
                    )
                    onBack()
                },
                modifier = Modifier.fillMaxWidth()
            ) { Text(tr("Save", "সংরক্ষণ")) }
        }
    }

    if (confirmDelete) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            title = { Text(tr("Delete task?", "কাজটি মুছবেন?")) },
            confirmButton = {
                TextButton(onClick = {
                    confirmDelete = false
                    vm.deleteTask(base.id)
                    onBack()
                }) { Text(tr("Delete", "মুছুন"), color = MaterialTheme.colorScheme.error) }
            },
            dismissButton = {
                TextButton(onClick = { confirmDelete = false }) { Text(tr("Cancel", "বাতিল")) }
            }
        )
    }
}
