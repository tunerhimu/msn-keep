package com.tunerhimu.msnkeep.reminder

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationManagerCompat
import com.tunerhimu.msnkeep.data.AppDatabase
import com.tunerhimu.msnkeep.data.SettingKeys
import com.tunerhimu.msnkeep.data.dataStore
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val pending = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val kind = intent.getStringExtra("kind") ?: "test"
                val id = intent.getLongExtra("id", 0L)
                val dao = AppDatabase.get(context).dao()
                var show = true
                if (kind == ReminderScheduler.KIND_TASK) {
                    val t = dao.getTask(id)
                    show = t != null && !t.done
                } else if (kind == ReminderScheduler.KIND_EVENT) {
                    show = dao.getEvent(id) != null
                }
                if (show) {
                    val bn = context.dataStore.data.first()[SettingKeys.BN] ?: true
                    Notifier.show(context, intent, bn)
                }
                ReminderScheduler.rescheduleAll(context)
            } finally {
                pending.finish()
            }
        }
    }
}

class ActionReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val pending = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val notifId = intent.getIntExtra("notifId", 0)
                NotificationManagerCompat.from(context).cancel(notifId)
                val id = intent.getLongExtra("id", 0L)
                when (intent.action) {
                    Notifier.ACTION_DONE -> {
                        val t = AppDatabase.get(context).dao().getTask(id)
                        if (t != null && !t.done) ReminderScheduler.toggleDone(context, t)
                    }
                    Notifier.ACTION_SNOOZE -> {
                        ReminderScheduler.scheduleSnooze(
                            context,
                            intent.getStringExtra("kind") ?: "test",
                            id,
                            intent.getStringExtra("title") ?: "",
                            intent.getStringExtra("desc") ?: "",
                            intent.getIntExtra("minutes", 0),
                            notifId
                        )
                    }
                }
            } finally {
                pending.finish()
            }
        }
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val pending = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                Notifier.ensureChannel(context)
                ReminderScheduler.rescheduleAll(context)
            } finally {
                pending.finish()
            }
        }
    }
}
