package com.tunerhimu.msnkeep.util

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.provider.OpenableColumns
import android.widget.Toast
import androidx.core.content.FileProvider
import com.tunerhimu.msnkeep.data.Attachment
import java.io.File
import java.io.FileOutputStream
import java.util.UUID

object Files {
    fun attachDir(ctx: Context): File {
        val d = File(ctx.filesDir, "attachments")
        d.mkdirs()
        return d
    }

    fun displayName(ctx: Context, uri: Uri): String {
        var name: String? = null
        val c = ctx.contentResolver.query(uri, null, null, null, null)
        if (c != null) {
            c.use {
                if (it.moveToFirst()) {
                    val i = it.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (i >= 0) name = it.getString(i)
                }
            }
        }
        return name ?: "file"
    }

    fun copyIn(ctx: Context, noteId: Long, uri: Uri): Attachment? {
        val name = displayName(ctx, uri)
        val mime = ctx.contentResolver.getType(uri) ?: "application/octet-stream"
        val ext = name.substringAfterLast('.', "")
        val fileName = UUID.randomUUID().toString() + (if (ext.isNotEmpty() && ext.length <= 8) ".$ext" else "")
        val dest = File(attachDir(ctx), fileName)
        return try {
            val input = ctx.contentResolver.openInputStream(uri) ?: return null
            input.use { src -> FileOutputStream(dest).use { out -> src.copyTo(out) } }
            Attachment(noteId = noteId, name = name, mime = mime, path = dest.absolutePath, size = dest.length())
        } catch (e: Exception) {
            null
        }
    }

    fun uriFor(ctx: Context, file: File): Uri =
        FileProvider.getUriForFile(ctx, ctx.packageName + ".fileprovider", file)

    fun open(ctx: Context, file: File, mime: String) {
        try {
            val i = Intent(Intent.ACTION_VIEW)
            i.setDataAndType(uriFor(ctx, file), mime)
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            ctx.startActivity(i)
        } catch (e: Exception) {
            Toast.makeText(ctx, "No app found to open this file", Toast.LENGTH_SHORT).show()
        }
    }

    fun share(ctx: Context, file: File, mime: String) {
        try {
            val i = Intent(Intent.ACTION_SEND)
            i.type = mime
            i.putExtra(Intent.EXTRA_STREAM, uriFor(ctx, file))
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            ctx.startActivity(Intent.createChooser(i, null))
        } catch (e: Exception) {
            Toast.makeText(ctx, "Could not share this file", Toast.LENGTH_SHORT).show()
        }
    }

    fun decodeThumb(path: String, target: Int): Bitmap? {
        val bounds = BitmapFactory.Options()
        bounds.inJustDecodeBounds = true
        BitmapFactory.decodeFile(path, bounds)
        var sample = 1
        while (bounds.outWidth / sample > target * 2 || bounds.outHeight / sample > target * 2) sample *= 2
        val opts = BitmapFactory.Options()
        opts.inSampleSize = sample
        return BitmapFactory.decodeFile(path, opts)
    }
}
