package com.tunerhimu.msnkeep.export

import android.content.Context
import android.graphics.Color
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import android.text.StaticLayout
import android.text.TextPaint
import com.tunerhimu.msnkeep.data.Note
import java.io.File
import java.io.FileOutputStream

object Exporter {
    enum class Format(val ext: String, val mime: String) {
        TXT("txt", "text/plain"),
        MD("md", "text/markdown"),
        HTML("html", "text/html"),
        DOC("doc", "application/msword"),
        PDF("pdf", "application/pdf")
    }

    fun plainText(n: Note): String = buildString {
        if (n.title.isNotBlank()) append(n.title).append("\n\n")
        append(n.content)
        if (n.tags.isNotBlank()) append("\n\nTags: ").append(n.tags)
    }

    fun markdown(n: Note): String = buildString {
        append("# ").append(n.title.ifBlank { "Untitled" }).append("\n\n")
        append(n.content)
        if (n.tags.isNotBlank()) append("\n\n---\nTags: ").append(n.tags)
        append("\n")
    }

    private fun esc(s: String): String =
        s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")

    fun html(n: Note, forWord: Boolean): String {
        val ns = if (forWord) " xmlns:o='urn:schemas-microsoft-com:office:office' xmlns:w='urn:schemas-microsoft-com:office:word'" else ""
        val body = esc(n.content).replace("\n", "<br>\n")
        val tags = if (n.tags.isBlank()) "" else "<p><i>Tags: " + esc(n.tags) + "</i></p>"
        return "<html$ns><head><meta charset=\"utf-8\"><title>" + esc(n.title) + "</title>" +
            "<style>body{font-family:sans-serif;max-width:720px;margin:24px auto;padding:0 16px;line-height:1.6}" +
            "h1{font-size:26px}</style></head><body><h1>" + esc(n.title.ifBlank { "Untitled" }) +
            "</h1><p>" + body + "</p>" + tags + "</body></html>"
    }

    private fun pdf(n: Note, out: File) {
        val pageW = 595
        val pageH = 842
        val margin = 48
        val width = pageW - 2 * margin
        val titlePaint = TextPaint(Paint.ANTI_ALIAS_FLAG)
        titlePaint.textSize = 22f
        titlePaint.isFakeBoldText = true
        titlePaint.color = Color.BLACK
        val bodyPaint = TextPaint(Paint.ANTI_ALIAS_FLAG)
        bodyPaint.textSize = 13f
        bodyPaint.color = Color.BLACK

        val title = n.title.ifBlank { "Untitled" }
        val body = n.content + (if (n.tags.isBlank()) "" else "\n\nTags: " + n.tags)
        val titleLayout = StaticLayout.Builder.obtain(title, 0, title.length, titlePaint, width).build()
        val bodyLayout = StaticLayout.Builder.obtain(body, 0, body.length, bodyPaint, width)
            .setLineSpacing(4f, 1f).build()

        val doc = PdfDocument()
        var line = 0
        var pageNo = 1
        do {
            val page = doc.startPage(PdfDocument.PageInfo.Builder(pageW, pageH, pageNo).create())
            val c = page.canvas
            var top = margin.toFloat()
            if (pageNo == 1) {
                c.save()
                c.translate(margin.toFloat(), top)
                titleLayout.draw(c)
                c.restore()
                top += titleLayout.height + 16f
            }
            val avail = pageH - margin - top
            val startTop = bodyLayout.getLineTop(line)
            var end = line
            while (end < bodyLayout.lineCount && bodyLayout.getLineBottom(end) - startTop <= avail) end++
            if (end == line) end = line + 1
            val last = if (end > bodyLayout.lineCount) bodyLayout.lineCount else end
            c.save()
            c.translate(margin.toFloat(), top)
            c.clipRect(0f, 0f, width.toFloat(), (bodyLayout.getLineBottom(last - 1) - startTop).toFloat())
            c.translate(0f, -startTop.toFloat())
            bodyLayout.draw(c)
            c.restore()
            doc.finishPage(page)
            line = last
            pageNo++
        } while (line < bodyLayout.lineCount)

        FileOutputStream(out).use { doc.writeTo(it) }
        doc.close()
    }

    fun write(ctx: Context, n: Note, fmt: Format): File {
        val dir = File(ctx.cacheDir, "exports")
        dir.mkdirs()
        val base = n.title.ifBlank { "note" }.replace(Regex("[^\\p{L}\\p{M}\\p{N}_-]+"), "_").take(40)
        val f = File(dir, base + "." + fmt.ext)
        when (fmt) {
            Format.TXT -> f.writeText(plainText(n))
            Format.MD -> f.writeText(markdown(n))
            Format.HTML -> f.writeText(html(n, false))
            Format.DOC -> f.writeText(html(n, true))
            Format.PDF -> pdf(n, f)
        }
        return f
    }
}
