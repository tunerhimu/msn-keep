package com.tunerhimu.msnkeep.reminder

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.tunerhimu.msnkeep.MainActivity
import com.tunerhimu.msnkeep.R

object Notifier {
    const val CHANNEL = "reminders"
    const val ACTION_DONE = "com.tunerhimu.msnkeep.ACTION_DONE"
    const val ACTION_SNOOZE = "com.tunerhimu.msnkeep.ACTION_SNOOZE"

    fun ensureChannel(ctx: Context) {
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = ctx.getSystemService(NotificationManager::class.java)
            if (nm.getNotificationChannel(CHANNEL) == null) {
                val ch = NotificationChannel(CHANNEL, "Reminders", NotificationManager.IMPORTANCE_HIGH)
                ch.description = "Task and event reminders"
                ch.enableVibration(true)
                nm.createNotificationChannel(ch)
            }
        }
    }

    fun leadText(min: Int, bn: Boolean): String = when {
        min == 0 -> if (bn) "এখনই" else "Now"
        min == 1440 -> if (bn) "আগামীকাল" else "Tomorrow"
        min % 60 == 0 -> if (bn) "${min / 60} ঘণ্টা পরে" else "In ${min / 60} h"
        else -> if (bn) "$min মিনিট পরে" else "In $min min"
    }

    private fun actionPi(ctx: Context, action: String, src: Intent, notifId: Int, offset: Int): PendingIntent {
        val i = Intent(ctx, ActionReceiver::class.java)
        i.action = action
        i.putExtras(src)
        return PendingIntent.getBroadcast(
            ctx, 800_000_000 + notifId * 3 + offset, i,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    fun show(ctx: Context, src: Intent, bn: Boolean) {
        if (Build.VERSION.SDK_INT >= 33 &&
            ctx.checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) return

        ensureChannel(ctx)
        val kind = src.getStringExtra("kind") ?: "test"
        val title = (src.getStringExtra("title") ?: "").ifBlank { "MSN Keep" }
        val desc = src.getStringExtra("desc") ?: ""
        val minutes = src.getIntExtra("minutes", 0)
        val notifId = src.getIntExtra("notifId", 1)
        val snoozed = src.getBooleanExtra("snoozed", false)

        val lead = when {
            kind == "test" -> if (bn) "টেস্ট রিমাইন্ডার — সব ঠিকঠাক কাজ করছে!" else "Test reminder — it works!"
            snoozed -> if (bn) "স্নুজ করা রিমাইন্ডার" else "Snoozed reminder"
            else -> leadText(minutes, bn)
        }
        val text = if (desc.isBlank()) lead else "$lead\n$desc"

        val open = PendingIntent.getActivity(
            ctx, notifId,
            Intent(ctx, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val b = NotificationCompat.Builder(ctx, CHANNEL)
            .setSmallIcon(R.drawable.ic_stat_note)
            .setContentTitle(title)
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_REMINDER)
            .setDefaults(NotificationCompat.DEFAULT_ALL)
            .setAutoCancel(true)
            .setContentIntent(open)
            .addAction(0, if (bn) "স্নুজ ১০ মি." else "Snooze 10 min", actionPi(ctx, ACTION_SNOOZE, src, notifId, 0))

        if (kind == "task") {
            b.addAction(0, if (bn) "সম্পন্ন" else "Done", actionPi(ctx, ACTION_DONE, src, notifId, 1))
        }
        NotificationManagerCompat.from(ctx).notify(notifId, b.build())
    }
}
