@file:OptIn(ExperimentalMaterial3Api::class)

package com.tunerhimu.msnkeep.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.sp
import java.util.Calendar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.tunerhimu.msnkeep.MainViewModel
import com.tunerhimu.msnkeep.data.Category
import com.tunerhimu.msnkeep.data.Note

@Composable
fun NotesTab(vm: MainViewModel, onOpen: (Long) -> Unit) {
    val notes by vm.notes.collectAsStateWithLifecycle()
    val cats by vm.categories.collectAsStateWithLifecycle()
    val query by vm.query.collectAsStateWithLifecycle()
    val filter by vm.categoryFilter.collectAsStateWithLifecycle()
    val grid by vm.grid.collectAsStateWithLifecycle()

    val hour = remember { Calendar.getInstance().get(Calendar.HOUR_OF_DAY) }
    val greeting = if (hour < 5) tr("Good night", "শুভ রাত্রি")
    else if (hour < 12) tr("Good morning", "শুভ সকাল")
    else if (hour < 17) tr("Good afternoon", "শুভ অপরাহ্ণ")
    else if (hour < 20) tr("Good evening", "শুভ সন্ধ্যা")
    else tr("Good night", "শুভ রাত্রি")

    Column(Modifier.fillMaxSize()) {
        Box(
            Modifier.fillMaxWidth().background(
                Brush.verticalGradient(
                    listOf(MaterialTheme.colorScheme.primaryContainer, MaterialTheme.colorScheme.background)
                )
            )
        ) {
            Column(Modifier.padding(start = 20.dp, end = 20.dp, top = 20.dp, bottom = 12.dp)) {
                Text(greeting, style = MaterialTheme.typography.headlineSmall)
                Text(
                    tr("${notes.size} notes", "${notes.size}টি নোট"),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(Modifier.height(14.dp))
                TextField(
                    value = query,
                    onValueChange = { vm.query.value = it },
                    modifier = Modifier.fillMaxWidth(),
                    placeholder = { Text(tr("Search notes", "নোট খুঁজুন")) },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                    trailingIcon = {
                        if (query.isNotEmpty()) {
                            IconButton(onClick = { vm.query.value = "" }) {
                                Icon(Icons.Default.Close, contentDescription = null)
                            }
                        }
                    },
                    singleLine = true,
                    shape = RoundedCornerShape(28.dp),
                    colors = TextFieldDefaults.colors(
                        focusedIndicatorColor = Color.Transparent,
                        unfocusedIndicatorColor = Color.Transparent,
                        disabledIndicatorColor = Color.Transparent,
                        focusedContainerColor = MaterialTheme.colorScheme.surface,
                        unfocusedContainerColor = MaterialTheme.colorScheme.surface
                    )
                )
            }
        }
        LazyRow(
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            item {
                FilterChip(
                    selected = filter == null,
                    onClick = { vm.categoryFilter.value = null },
                    label = { Text(tr("All", "সব")) }
                )
            }
            items(cats, key = { it.id }) { c ->
                FilterChip(
                    selected = filter == c.id,
                    onClick = { vm.categoryFilter.value = if (filter == c.id) null else c.id },
                    label = { Text(c.name) },
                    leadingIcon = {
                        Box(
                            Modifier.size(10.dp)
                                .background(Accent[c.colorIndex.coerceIn(0, Accent.lastIndex)], CircleShape)
                        )
                    }
                )
            }
        }

        if (notes.isEmpty()) {
            Column(
                Modifier.fillMaxSize().padding(32.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Text("📝", fontSize = 56.sp)
                Spacer(Modifier.height(12.dp))
                Text(
                    if (query.isBlank()) tr(
                        "No notes yet. Tap New note to write your first one.",
                        "এখনো কোনো নোট নেই। \"নতুন নোট\" চেপে প্রথম নোট লিখুন।"
                    ) else tr("No results found.", "কিছু পাওয়া যায়নি।"),
                    style = MaterialTheme.typography.bodyLarge,
                    textAlign = TextAlign.Center
                )
            }
        } else if (grid) {
            LazyVerticalGrid(
                columns = GridCells.Fixed(2),
                contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 96.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(notes, key = { it.id }) { n -> NoteCard(n, cats, onOpen) }
            }
        } else {
            LazyColumn(
                contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 96.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(notes, key = { it.id }) { n -> NoteCard(n, cats, onOpen) }
            }
        }
    }
}

@Composable
fun NoteCard(n: Note, cats: List<Category>, onOpen: (Long) -> Unit) {
    val bg = noteBg(n.colorIndex)
    val fg = noteFg(n.colorIndex)
    val untitled = tr("Untitled", "শিরোনামহীন")
    val cat = cats.firstOrNull { it.id == n.categoryId }
    val meta = listOfNotNull(cat?.name, n.tags.takeIf { it.isNotBlank() }).joinToString(" • ")

    Card(
        onClick = { onOpen(n.id) },
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(24.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 3.dp),
        colors = CardDefaults.cardColors(containerColor = bg, contentColor = fg)
    ) {
        Column(Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    n.title.ifBlank { untitled },
                    fontWeight = FontWeight.Bold,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                    style = MaterialTheme.typography.titleMedium,
                    modifier = Modifier.weight(1f)
                )
                if (n.pinned) {
                    Icon(
                        Icons.Default.Star, contentDescription = null,
                        tint = Color(0xFFF9A825), modifier = Modifier.size(18.dp)
                    )
                }
            }
            if (n.content.isNotBlank()) {
                Text(
                    n.content,
                    maxLines = 6,
                    overflow = TextOverflow.Ellipsis,
                    style = MaterialTheme.typography.bodyMedium,
                    modifier = Modifier.padding(top = 8.dp)
                )
            }
            if (meta.isNotBlank()) {
                Text(
                    meta,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    style = MaterialTheme.typography.labelSmall,
                    color = fg.copy(alpha = 0.7f),
                    modifier = Modifier.padding(top = 10.dp)
                )
            }
        }
    }
}

@Composable
fun ColorRow(selected: Int, accent: Boolean, onPick: (Int) -> Unit) {
    Row(
        Modifier.horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        val range = if (accent) 1..7 else 0..7
        for (i in range) {
            val c = if (accent) Accent[i] else noteBg(i)
            val borderColor =
                if (selected == i) MaterialTheme.colorScheme.primary
                else MaterialTheme.colorScheme.outlineVariant
            Box(
                Modifier.size(34.dp)
                    .clip(CircleShape)
                    .background(c)
                    .border(if (selected == i) 3.dp else 1.dp, borderColor, CircleShape)
                    .clickable { onPick(i) }
            )
        }
    }
}

@Composable
fun CategoriesTab(vm: MainViewModel) {
    val cats by vm.categories.collectAsStateWithLifecycle()
    val notes by vm.allNotes.collectAsStateWithLifecycle()
    var editing by remember { mutableStateOf<Category?>(null) }
    var creating by remember { mutableStateOf(false) }

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(
                tr("Categories", "ক্যাটাগরি"),
                style = MaterialTheme.typography.headlineSmall,
                modifier = Modifier.weight(1f)
            )
            FilledTonalButton(onClick = { creating = true }) {
                Icon(Icons.Default.Add, contentDescription = null)
                Spacer(Modifier.width(6.dp))
                Text(tr("New", "নতুন"))
            }
        }
        if (cats.isEmpty()) {
            Box(Modifier.fillMaxSize().padding(32.dp), contentAlignment = Alignment.Center) {
                Text(
                    tr("No categories yet. Create one to organize your notes.",
                        "এখনো কোনো ক্যাটাগরি নেই। নোট গুছিয়ে রাখতে একটি তৈরি করুন।"),
                    style = MaterialTheme.typography.bodyLarge
                )
            }
        } else {
            LazyColumn(
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 4.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(cats, key = { it.id }) { c ->
                    val count = notes.count { it.categoryId == c.id }
                    Card(onClick = { editing = c }, modifier = Modifier.fillMaxWidth()) {
                        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                Modifier.size(14.dp)
                                    .background(Accent[c.colorIndex.coerceIn(0, Accent.lastIndex)], CircleShape)
                            )
                            Spacer(Modifier.width(12.dp))
                            Text(c.name, style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
                            Text("$count", style = MaterialTheme.typography.bodyMedium)
                        }
                    }
                }
            }
        }
    }

    if (creating) {
        CategoryDialog(
            existing = null,
            onDismiss = { creating = false },
            onSave = { name, color -> vm.addCategory(name, color); creating = false },
            onDelete = null
        )
    }
    val current = editing
    if (current != null) {
        CategoryDialog(
            existing = current,
            onDismiss = { editing = null },
            onSave = { name, color -> vm.updateCategory(current.copy(name = name, colorIndex = color)); editing = null },
            onDelete = { vm.deleteCategory(current); editing = null }
        )
    }
}

@Composable
fun CategoryDialog(
    existing: Category?,
    onDismiss: () -> Unit,
    onSave: (String, Int) -> Unit,
    onDelete: (() -> Unit)?
) {
    var name by remember { mutableStateOf(existing?.name ?: "") }
    var color by remember { mutableStateOf(existing?.colorIndex ?: 1) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                if (existing == null) tr("New category", "নতুন ক্যাটাগরি")
                else tr("Edit category", "ক্যাটাগরি সম্পাদনা")
            )
        },
        text = {
            Column {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    singleLine = true,
                    label = { Text(tr("Name", "নাম")) }
                )
                Spacer(Modifier.height(16.dp))
                ColorRow(selected = color, accent = true, onPick = { color = it })
            }
        },
        confirmButton = {
            TextButton(onClick = { if (name.isNotBlank()) onSave(name.trim(), color) }) {
                Text(tr("Save", "সংরক্ষণ"))
            }
        },
        dismissButton = {
            Row {
                if (onDelete != null) {
                    TextButton(onClick = onDelete) {
                        Text(tr("Delete", "মুছুন"), color = MaterialTheme.colorScheme.error)
                    }
                }
                TextButton(onClick = onDismiss) { Text(tr("Cancel", "বাতিল")) }
            }
        }
    )
}

@Composable
fun TrashTab(vm: MainViewModel) {
    val trashed by vm.trashedNotes.collectAsStateWithLifecycle()
    var confirm by remember { mutableStateOf(false) }
    val untitled = tr("Untitled", "শিরোনামহীন")

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(
                tr("Trash", "ট্র্যাশ"),
                style = MaterialTheme.typography.headlineSmall,
                modifier = Modifier.weight(1f)
            )
            if (trashed.isNotEmpty()) {
                TextButton(onClick = { confirm = true }) { Text(tr("Empty trash", "ট্র্যাশ খালি করুন")) }
            }
        }
        if (trashed.isEmpty()) {
            Box(Modifier.fillMaxSize().padding(32.dp), contentAlignment = Alignment.Center) {
                Text(tr("Trash is empty.", "ট্র্যাশ খালি আছে।"), style = MaterialTheme.typography.bodyLarge)
            }
        } else {
            LazyColumn(
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 4.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(trashed, key = { it.id }) { n ->
                    Card(modifier = Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(16.dp)) {
                            Text(
                                n.title.ifBlank { untitled },
                                fontWeight = FontWeight.Bold,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            if (n.content.isNotBlank()) {
                                Text(
                                    n.content, maxLines = 2, overflow = TextOverflow.Ellipsis,
                                    style = MaterialTheme.typography.bodySmall,
                                    modifier = Modifier.padding(top = 4.dp)
                                )
                            }
                            Row {
                                TextButton(onClick = { vm.restore(n.id) }) { Text(tr("Restore", "পুনরুদ্ধার")) }
                                TextButton(onClick = { vm.deleteForever(n.id) }) {
                                    Text(tr("Delete forever", "চিরতরে মুছুন"), color = MaterialTheme.colorScheme.error)
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (confirm) {
        AlertDialog(
            onDismissRequest = { confirm = false },
            title = { Text(tr("Empty trash?", "ট্র্যাশ খালি করবেন?")) },
            text = {
                Text(tr("All notes in trash will be deleted permanently.",
                    "ট্র্যাশের সব নোট চিরতরে মুছে যাবে।"))
            },
            confirmButton = {
                TextButton(onClick = { vm.emptyTrash(); confirm = false }) {
                    Text(tr("Delete", "মুছুন"), color = MaterialTheme.colorScheme.error)
                }
            },
            dismissButton = {
                TextButton(onClick = { confirm = false }) { Text(tr("Cancel", "বাতিল")) }
            }
        )
    }
}
