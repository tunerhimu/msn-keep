@file:OptIn(ExperimentalMaterial3Api::class)

package com.tunerhimu.msnkeep.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.tunerhimu.msnkeep.MainViewModel
import kotlinx.coroutines.launch

@Composable
fun AppNav(vm: MainViewModel) {
    val nav = rememberNavController()
    NavHost(navController = nav, startDestination = "main") {
        composable("main") {
            MainScreen(
                vm = vm,
                onOpenNote = { id -> nav.navigate("editor/$id") },
                onOpenTask = { id -> nav.navigate("task/$id") },
                onOpenEvent = { id -> nav.navigate("event/$id") },
                onAbout = { nav.navigate("about") }
            )
        }
        composable(
            route = "editor/{id}",
            arguments = listOf(navArgument("id") { type = NavType.LongType })
        ) { entry ->
            EditorScreen(vm, entry.arguments?.getLong("id") ?: 0L) { nav.popBackStack() }
        }
        composable(
            route = "task/{id}",
            arguments = listOf(navArgument("id") { type = NavType.LongType })
        ) { entry ->
            TaskEditorScreen(vm, entry.arguments?.getLong("id") ?: 0L) { nav.popBackStack() }
        }
        composable(
            route = "event/{id}",
            arguments = listOf(navArgument("id") { type = NavType.LongType })
        ) { entry ->
            EventEditorScreen(vm, entry.arguments?.getLong("id") ?: 0L) { nav.popBackStack() }
        }
        composable("about") {
            AboutScreen(onBack = { nav.popBackStack() })
        }
    }
}

@Composable
fun MainScreen(
    vm: MainViewModel,
    onOpenNote: (Long) -> Unit,
    onOpenTask: (Long) -> Unit,
    onOpenEvent: (Long) -> Unit,
    onAbout: () -> Unit
) {
    var tab by rememberSaveable { mutableStateOf(0) }
    val scope = rememberCoroutineScope()

    Scaffold(
        bottomBar = {
            NavigationBar {
                NavigationBarItem(
                    selected = tab == 0, onClick = { tab = 0 },
                    icon = { Icon(Icons.Default.Home, contentDescription = null) },
                    label = { Text(tr("Notes", "নোট")) }
                )
                NavigationBarItem(
                    selected = tab == 1, onClick = { tab = 1 },
                    icon = { Icon(Icons.Default.Check, contentDescription = null) },
                    label = { Text(tr("Tasks", "কাজ")) }
                )
                NavigationBarItem(
                    selected = tab == 2, onClick = { tab = 2 },
                    icon = { Icon(Icons.Default.DateRange, contentDescription = null) },
                    label = { Text(tr("Agenda", "এজেন্ডা")) }
                )
                NavigationBarItem(
                    selected = tab == 3, onClick = { tab = 3 },
                    icon = { Icon(Icons.Default.Menu, contentDescription = null) },
                    label = { Text(tr("More", "আরও")) }
                )
            }
        },
        floatingActionButton = {
            if (tab in 0..2) {
                FloatingActionButton(onClick = {
                    when (tab) {
                        0 -> scope.launch {
                            val id = vm.createNote()
                            onOpenNote(id)
                        }
                        1 -> onOpenTask(0L)
                        else -> onOpenEvent(0L)
                    }
                }) {
                    Icon(Icons.Default.Add, contentDescription = null)
                }
            }
        }
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            when (tab) {
                0 -> NotesTab(vm, onOpenNote)
                1 -> TasksTab(vm, onOpenTask)
                2 -> AgendaTab(vm, onOpenTask, onOpenEvent)
                else -> MoreTab(vm, onAbout)
            }
        }
    }
}

@Composable
fun MoreTab(vm: MainViewModel, onAbout: () -> Unit) {
    var page by rememberSaveable { mutableStateOf(0) }
    BackHandler(enabled = page != 0) { page = 0 }

    when (page) {
        1 -> CategoriesTab(vm)
        2 -> TrashTab(vm)
        3 -> SettingsTab(vm, onAbout)
        else -> Column(
            Modifier.fillMaxSize().padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(tr("More", "আরও"), style = MaterialTheme.typography.headlineSmall)
            MoreItem(tr("Categories", "ক্যাটাগরি"), tr("Organize your notes", "নোট গুছিয়ে রাখুন")) { page = 1 }
            MoreItem(tr("Trash", "ট্র্যাশ"), tr("Restore deleted notes", "মুছে ফেলা নোট ফিরিয়ে আনুন")) { page = 2 }
            MoreItem(tr("Settings", "সেটিংস"), tr("Theme, language, reminders", "থিম, ভাষা, রিমাইন্ডার")) { page = 3 }
        }
    }
}

@Composable
private fun MoreItem(title: String, subtitle: String, onClick: () -> Unit) {
    Card(onClick = onClick, modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium)
            Text(subtitle, style = MaterialTheme.typography.bodySmall)
        }
    }
}
