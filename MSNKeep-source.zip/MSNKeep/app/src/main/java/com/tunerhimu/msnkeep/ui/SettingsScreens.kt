@file:OptIn(ExperimentalMaterial3Api::class)

package com.tunerhimu.msnkeep.ui

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.tunerhimu.msnkeep.MainViewModel
import com.tunerhimu.msnkeep.reminder.ReminderScheduler

object Links {
    const val WEBSITE = "https://tunerhimu.github.io"
    const val FACEBOOK = "https://facebook.com/TunerHimu"
    const val YOUTUBE = "https://youtube.com/TunerHimu"
}

@Composable
private fun Section(title: String, content: @Composable () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium)
            content()
        }
    }
}

@Composable
private fun ChipRow(content: @Composable RowScope.() -> Unit) {
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), content = content)
}

@Composable
private fun DeveloperLinks() {
    val uri = LocalUriHandler.current
    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
        TextButton(onClick = { uri.openUri(Links.WEBSITE) }) { Text("Website") }
        TextButton(onClick = { uri.openUri(Links.FACEBOOK) }) { Text("Facebook") }
        TextButton(onClick = { uri.openUri(Links.YOUTUBE) }) { Text("YouTube") }
    }
}

@Composable
fun SettingsTab(vm: MainViewModel, onAbout: () -> Unit) {
    val theme by vm.themeMode.collectAsStateWithLifecycle()
    val bn by vm.bengali.collectAsStateWithLifecycle()
    val grid by vm.grid.collectAsStateWithLifecycle()

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(tr("Settings", "সেটিংস"), style = MaterialTheme.typography.headlineSmall)

        Section(tr("Appearance", "চেহারা")) {
            Text(tr("Theme", "থিম"), style = MaterialTheme.typography.labelLarge)
            ChipRow {
                FilterChip(selected = theme == 0, onClick = { vm.setTheme(0) }, label = { Text(tr("System", "সিস্টেম")) })
                FilterChip(selected = theme == 1, onClick = { vm.setTheme(1) }, label = { Text(tr("Light", "লাইট")) })
                FilterChip(selected = theme == 2, onClick = { vm.setTheme(2) }, label = { Text(tr("Dark", "ডার্ক")) })
            }
            Text(tr("Language", "ভাষা"), style = MaterialTheme.typography.labelLarge)
            ChipRow {
                FilterChip(selected = bn, onClick = { vm.setBengali(true) }, label = { Text("বাংলা") })
                FilterChip(selected = !bn, onClick = { vm.setBengali(false) }, label = { Text("English") })
            }
            Text(tr("Notes layout", "নোটের লেআউট"), style = MaterialTheme.typography.labelLarge)
            ChipRow {
                FilterChip(selected = grid, onClick = { vm.setGrid(true) }, label = { Text(tr("Grid", "গ্রিড")) })
                FilterChip(selected = !grid, onClick = { vm.setGrid(false) }, label = { Text(tr("List", "তালিকা")) })
            }
        }

        ReminderTools()

        OutlinedButton(onClick = onAbout, modifier = Modifier.fillMaxWidth()) {
            Text(tr("About MSN Keep", "MSN Keep সম্পর্কে"))
        }

        Section(tr("Developer", "ডেভেলপার")) {
            Text("TunerHimu", style = MaterialTheme.typography.titleLarge)
            DeveloperLinks()
        }
    }
}

@Composable
private fun ReminderTools() {
    val ctx = LocalContext.current
    val canExact = ReminderScheduler.canScheduleExact(ctx)
    var sent by remember { mutableStateOf(false) }

    Section(tr("Reminders", "রিমাইন্ডার")) {
        Text(
            tr(
                "Reminders use Android alarms and survive a restart. Strict battery saver modes on some phones can still delay them.",
                "রিমাইন্ডার অ্যান্ড্রয়েড অ্যালার্ম ব্যবহার করে এবং ফোন রিস্টার্টের পরেও চালু থাকে। তবে কিছু ফোনের কড়া ব্যাটারি সেভার মোড দেরি করাতে পারে।"
            ),
            style = MaterialTheme.typography.bodySmall
        )
        OutlinedButton(onClick = {
            ReminderScheduler.scheduleTest(ctx, 10)
            sent = true
        }) {
            Text(
                if (sent) tr("Test set — wait 10 seconds", "টেস্ট সেট হয়েছে — ১০ সেকেন্ড অপেক্ষা করুন")
                else tr("Send a test reminder in 10 s", "১০ সেকেন্ড পরে টেস্ট রিমাইন্ডার")
            )
        }
        OutlinedButton(onClick = {
            val i = Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
            i.putExtra(Settings.EXTRA_APP_PACKAGE, ctx.packageName)
            ctx.startActivity(i)
        }) { Text(tr("Notification settings", "নোটিফিকেশন সেটিংস")) }
        if (!canExact && Build.VERSION.SDK_INT >= 31) {
            OutlinedButton(onClick = {
                val i = Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM)
                i.data = Uri.parse("package:" + ctx.packageName)
                ctx.startActivity(i)
            }) { Text(tr("Allow exact alarms", "সঠিক সময়ের অ্যালার্মের অনুমতি দিন")) }
        }
    }
}

@Composable
fun AboutScreen(onBack: () -> Unit) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(tr("About", "সম্পর্কে")) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = null)
                    }
                }
            )
        }
    ) { pad ->
        Column(
            Modifier.padding(pad).fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text("MSN Keep", style = MaterialTheme.typography.headlineMedium)
            Text(tr("Version 0.3.0", "ভার্সন ০.৩.০"), style = MaterialTheme.typography.labelLarge)
            Text(
                tr(
                    "A private note-taking, task and reminder app. Your data stays on your phone unless you back it up.",
                    "একটি প্রাইভেট নোট, কাজ ও রিমাইন্ডার অ্যাপ। ব্যাকআপ না নিলে আপনার ডাটা ফোনেই থাকে।"
                ),
                style = MaterialTheme.typography.bodyLarge
            )
            Section(tr("Developed by", "ডেভেলপার")) {
                Text("TunerHimu", style = MaterialTheme.typography.titleLarge)
                DeveloperLinks()
            }
        }
    }
}
