@file:OptIn(ExperimentalMaterial3Api::class)

package com.tunerhimu.msnkeep.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.tunerhimu.msnkeep.MainViewModel

object Links {
    const val WEBSITE = "https://tunerhimu.github.io"
    const val FACEBOOK = "https://facebook.com/TunerHimu"
    const val YOUTUBE = "https://youtube.com/TunerHimu"
}

@Composable
private fun ChipRow(title: String, content: @Composable RowScope.() -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(title, style = MaterialTheme.typography.titleSmall)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), content = content)
    }
}

@Composable
private fun DeveloperLinks() {
    val uri = LocalUriHandler.current
    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
        TextButton(onClick = { uri.openUri(Links.WEBSITE) }) { Text("Website") }
        TextButton(onClick = { uri.openUri(Links.FACEBOOK) }) { Text("Facebook") }
        TextButton(onClick = { uri.openUri(Links.YOUTUBE) }) { Text("YouTube") }
    }
}

@Composable
fun SettingsTab(vm: MainViewModel, onAbout: () -> Unit) {
    val theme by vm.themeMode.collectAsStateWithLifecycle()
    val bn by vm.bengali.collectAsStateWithLifecycle()
    val grid by vm.grid.collectAsStateWithLifecycle()

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(20.dp)
    ) {
        Text(tr("Settings", "সেটিংস"), style = MaterialTheme.typography.headlineSmall)

        ChipRow(tr("Theme", "থিম")) {
            FilterChip(selected = theme == 0, onClick = { vm.setTheme(0) }, label = { Text(tr("System", "সিস্টেম")) })
            FilterChip(selected = theme == 1, onClick = { vm.setTheme(1) }, label = { Text(tr("Light", "লাইট")) })
            FilterChip(selected = theme == 2, onClick = { vm.setTheme(2) }, label = { Text(tr("Dark", "ডার্ক")) })
        }
        ChipRow(tr("Language", "ভাষা")) {
            FilterChip(selected = bn, onClick = { vm.setBengali(true) }, label = { Text("বাংলা") })
            FilterChip(selected = !bn, onClick = { vm.setBengali(false) }, label = { Text("English") })
        }
        ChipRow(tr("Notes layout", "নোটের লেআউট")) {
            FilterChip(selected = grid, onClick = { vm.setGrid(true) }, label = { Text(tr("Grid", "গ্রিড")) })
            FilterChip(selected = !grid, onClick = { vm.setGrid(false) }, label = { Text(tr("List", "তালিকা")) })
        }

        OutlinedButton(onClick = onAbout, modifier = Modifier.fillMaxWidth()) {
            Text(tr("About MSN Keep", "MSN Keep সম্পর্কে"))
        }

        Card(modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp)) {
                Text(tr("Developer", "ডেভেলপার"), style = MaterialTheme.typography.labelMedium)
                Text("TunerHimu", style = MaterialTheme.typography.titleMedium)
                DeveloperLinks()
            }
        }
    }
}

@Composable
fun AboutScreen(onBack: () -> Unit) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(tr("About", "সম্পর্কে")) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = null)
                    }
                }
            )
        }
    ) { pad ->
        Column(
            Modifier.padding(pad).fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text("MSN Keep", style = MaterialTheme.typography.headlineMedium)
            Text(tr("Version 0.1.0", "ভার্সন ০.১.০"), style = MaterialTheme.typography.labelLarge)
            Text(
                tr(
                    "A private, offline note-taking app. Your notes stay on your phone.",
                    "একটি প্রাইভেট, অফলাইন নোট অ্যাপ। আপনার নোট আপনার ফোনেই থাকে।"
                ),
                style = MaterialTheme.typography.bodyLarge
            )
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp)) {
                    Text(tr("Developed by", "ডেভেলপার"), style = MaterialTheme.typography.labelMedium)
                    Text("TunerHimu", style = MaterialTheme.typography.titleLarge)
                    DeveloperLinks()
                }
            }
        }
    }
}
