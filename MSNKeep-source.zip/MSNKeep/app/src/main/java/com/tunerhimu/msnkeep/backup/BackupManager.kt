package com.tunerhimu.msnkeep.backup

import android.content.Context
import android.net.Uri
import androidx.room.withTransaction
import com.tunerhimu.msnkeep.data.AppDatabase
import com.tunerhimu.msnkeep.data.Attachment
import com.tunerhimu.msnkeep.data.Category
import com.tunerhimu.msnkeep.data.Event
import com.tunerhimu.msnkeep.data.Note
import com.tunerhimu.msnkeep.data.NoteVersion
import com.tunerhimu.msnkeep.data.Task
import com.tunerhimu.msnkeep.reminder.ReminderScheduler
import com.tunerhimu.msnkeep.util.Files
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

object BackupManager {
    private fun nullableLong(o: JSONObject, k: String): Long? = if (o.isNull(k)) null else o.getLong(k)

    suspend fun export(ctx: Context, uri: Uri): Boolean = withContext(Dispatchers.IO) {
        try {
            val dao = AppDatabase.get(ctx).dao()
            val root = JSONObject()
            root.put("app", "MSNKeep")
            root.put("format", 1)
            root.put("exportedAt", System.currentTimeMillis())

            val notes = JSONArray()
            for (n in dao.allNotesOnce()) {
                val o = JSONObject()
                o.put("id", n.id); o.put("title", n.title); o.put("content", n.content)
                o.put("tags", n.tags); o.put("colorIndex", n.colorIndex); o.put("pinned", n.pinned)
                o.put("categoryId", n.categoryId ?: JSONObject.NULL)
                o.put("deleted", n.deleted); o.put("createdAt", n.createdAt); o.put("updatedAt", n.updatedAt)
                notes.put(o)
            }
            root.put("notes", notes)

            val cats = JSONArray()
            for (c in dao.categoriesOnce()) {
                val o = JSONObject()
                o.put("id", c.id); o.put("name", c.name); o.put("colorIndex", c.colorIndex)
                cats.put(o)
            }
            root.put("categories", cats)

            val tasks = JSONArray()
            for (t in dao.tasksOnce()) {
                val o = JSONObject()
                o.put("id", t.id); o.put("title", t.title); o.put("description", t.description)
                o.put("dueAt", t.dueAt ?: JSONObject.NULL)
                o.put("priority", t.priority); o.put("done", t.done); o.put("repeatMode", t.repeatMode)
                o.put("alerts", t.alerts); o.put("completedAt", t.completedAt ?: JSONObject.NULL)
                o.put("createdAt", t.createdAt)
                tasks.put(o)
            }
            root.put("tasks", tasks)

            val events = JSONArray()
            for (e in dao.eventsOnce()) {
                val o = JSONObject()
                o.put("id", e.id); o.put("title", e.title); o.put("description", e.description)
                o.put("startAt", e.startAt); o.put("endAt", e.endAt); o.put("location", e.location)
                o.put("repeatMode", e.repeatMode); o.put("alerts", e.alerts)
                events.put(o)
            }
            root.put("events", events)

            val versions = JSONArray()
            for (v in dao.allVersions()) {
                val o = JSONObject()
                o.put("id", v.id); o.put("noteId", v.noteId); o.put("title", v.title)
                o.put("content", v.content); o.put("savedAt", v.savedAt)
                versions.put(o)
            }
            root.put("versions", versions)

            val atts = dao.allAttachments()
            val attJson = JSONArray()
            for (a in atts) {
                val o = JSONObject()
                o.put("id", a.id); o.put("noteId", a.noteId); o.put("name", a.name)
                o.put("mime", a.mime); o.put("file", File(a.path).name); o.put("size", a.size)
                attJson.put(o)
            }
            root.put("attachments", attJson)

            val stream = ctx.contentResolver.openOutputStream(uri) ?: return@withContext false
            stream.use { os ->
                ZipOutputStream(os).use { zip ->
                    zip.putNextEntry(ZipEntry("data.json"))
                    zip.write(root.toString().toByteArray(Charsets.UTF_8))
                    zip.closeEntry()
                    for (a in atts) {
                        val f = File(a.path)
                        if (f.exists()) {
                            zip.putNextEntry(ZipEntry("attachments/" + f.name))
                            f.inputStream().use { it.copyTo(zip) }
                            zip.closeEntry()
                        }
                    }
                }
            }
            true
        } catch (e: Exception) {
            false
        }
    }

    suspend fun restore(ctx: Context, uri: Uri): Boolean = withContext(Dispatchers.IO) {
        val tmp = File(ctx.cacheDir, "restore_tmp")
        try {
            tmp.deleteRecursively()
            tmp.mkdirs()
            var json: String? = null
            val input = ctx.contentResolver.openInputStream(uri) ?: return@withContext false
            input.use { raw ->
                ZipInputStream(raw).use { zip ->
                    var entry = zip.nextEntry
                    while (entry != null) {
                        val name = entry.name
                        if (!entry.isDirectory) {
                            if (name == "data.json") {
                                json = zip.readBytes().toString(Charsets.UTF_8)
                            } else if (name.startsWith("attachments/")) {
                                File(tmp, File(name).name).outputStream().use { out -> zip.copyTo(out) }
                            }
                        }
                        zip.closeEntry()
                        entry = zip.nextEntry
                    }
                }
            }
            val text = json ?: return@withContext false
            val root = JSONObject(text)
            if (root.optString("app") != "MSNKeep") return@withContext false

            val db = AppDatabase.get(ctx)
            val dao = db.dao()
            val attachDir = Files.attachDir(ctx)

            db.withTransaction {
                dao.clearNotes(); dao.clearCategories(); dao.clearTasks()
                dao.clearEvents(); dao.clearVersions(); dao.clearAttachments()

                val notes = root.optJSONArray("notes")
                if (notes != null) for (i in 0 until notes.length()) {
                    val o = notes.getJSONObject(i)
                    dao.upsert(
                        Note(
                            id = o.getLong("id"), title = o.optString("title"), content = o.optString("content"),
                            tags = o.optString("tags"), colorIndex = o.optInt("colorIndex"),
                            pinned = o.optBoolean("pinned"), categoryId = nullableLong(o, "categoryId"),
                            deleted = o.optBoolean("deleted"), createdAt = o.optLong("createdAt"),
                            updatedAt = o.optLong("updatedAt")
                        )
                    )
                }
                val cats = root.optJSONArray("categories")
                if (cats != null) for (i in 0 until cats.length()) {
                    val o = cats.getJSONObject(i)
                    dao.upsertCategory(Category(id = o.getLong("id"), name = o.optString("name"), colorIndex = o.optInt("colorIndex", 1)))
                }
                val tasks = root.optJSONArray("tasks")
                if (tasks != null) for (i in 0 until tasks.length()) {
                    val o = tasks.getJSONObject(i)
                    dao.upsertTask(
                        Task(
                            id = o.getLong("id"), title = o.optString("title"), description = o.optString("description"),
                            dueAt = nullableLong(o, "dueAt"), priority = o.optInt("priority", 1),
                            done = o.optBoolean("done"), repeatMode = o.optInt("repeatMode"),
                            alerts = o.optString("alerts", "0"), completedAt = nullableLong(o, "completedAt"),
                            createdAt = o.optLong("createdAt")
                        )
                    )
                }
                val events = root.optJSONArray("events")
                if (events != null) for (i in 0 until events.length()) {
                    val o = events.getJSONObject(i)
                    dao.upsertEvent(
                        Event(
                            id = o.getLong("id"), title = o.optString("title"), description = o.optString("description"),
                            startAt = o.getLong("startAt"), endAt = o.getLong("endAt"),
                            location = o.optString("location"), repeatMode = o.optInt("repeatMode"),
                            alerts = o.optString("alerts", "30")
                        )
                    )
                }
                val versions = root.optJSONArray("versions")
                if (versions != null) for (i in 0 until versions.length()) {
                    val o = versions.getJSONObject(i)
                    dao.insertVersion(
                        NoteVersion(
                            id = o.getLong("id"), noteId = o.getLong("noteId"), title = o.optString("title"),
                            content = o.optString("content"), savedAt = o.optLong("savedAt")
                        )
                    )
                }
                val atts = root.optJSONArray("attachments")
                if (atts != null) for (i in 0 until atts.length()) {
                    val o = atts.getJSONObject(i)
                    dao.insertAttachment(
                        Attachment(
                            id = o.getLong("id"), noteId = o.getLong("noteId"), name = o.optString("name"),
                            mime = o.optString("mime", "application/octet-stream"),
                            path = File(attachDir, File(o.getString("file")).name).absolutePath,
                            size = o.optLong("size")
                        )
                    )
                }
            }

            attachDir.listFiles()?.forEach { it.delete() }
            tmp.listFiles()?.forEach { it.copyTo(File(attachDir, it.name), overwrite = true) }
            ReminderScheduler.rescheduleAll(ctx)
            tmp.deleteRecursively()
            true
        } catch (e: Exception) {
            tmp.deleteRecursively()
            false
        }
    }
}
