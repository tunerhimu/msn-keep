@file:OptIn(ExperimentalMaterial3Api::class)

package com.tunerhimu.msnkeep.ui

import android.content.Intent
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.tunerhimu.msnkeep.MainViewModel
import com.tunerhimu.msnkeep.data.Note
import kotlinx.coroutines.delay

@Composable
fun EditorScreen(vm: MainViewModel, noteId: Long, onBack: () -> Unit) {
    var base by remember { mutableStateOf<Note?>(null) }
    LaunchedEffect(noteId) { base = vm.load(noteId) }
    val loaded = base
    if (loaded == null) {
        Box(Modifier.fillMaxSize())
    } else {
        EditorContent(vm, loaded, onBack)
    }
}

@Composable
private fun EditorContent(vm: MainViewModel, base: Note, onBack: () -> Unit) {
    var title by remember { mutableStateOf(base.title) }
    var content by remember { mutableStateOf(base.content) }
    var tags by remember { mutableStateOf(base.tags) }
    var color by remember { mutableStateOf(base.colorIndex) }
    var pinned by remember { mutableStateOf(base.pinned) }
    var categoryId by remember { mutableStateOf(base.categoryId) }
    var trashed by remember { mutableStateOf(false) }
    val cats by vm.categories.collectAsStateWithLifecycle()
    val ctx = LocalContext.current

    fun snapshot(): Note = base.copy(
        title = title, content = content, tags = tags,
        colorIndex = color, pinned = pinned, categoryId = categoryId
    )

    // Auto-save shortly after the last change
    LaunchedEffect(title, content, tags, color, pinned, categoryId) {
        delay(500)
        val s = snapshot()
        if (s != base && !trashed) vm.save(s)
    }

    // Save (or discard an empty new note) when leaving the editor
    DisposableEffect(Unit) {
        onDispose {
            if (!trashed) {
                val s = snapshot()
                val wasEmpty = base.title.isBlank() && base.content.isBlank()
                if (s.title.isBlank() && s.content.isBlank() && wasEmpty) {
                    vm.deleteForever(s.id)
                } else if (s != base) {
                    vm.save(s)
                }
            }
        }
    }

    fun share() {
        val send = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_SUBJECT, title)
            putExtra(Intent.EXTRA_TEXT, if (title.isBlank()) content else "$title\n\n$content")
        }
        ctx.startActivity(Intent.createChooser(send, null))
    }

    val bg = if (color == 0) MaterialTheme.colorScheme.background else noteBg(color)
    val fg = if (color == 0) MaterialTheme.colorScheme.onBackground else noteFg(color)
    val fieldColors = TextFieldDefaults.colors(
        focusedContainerColor = Color.Transparent,
        unfocusedContainerColor = Color.Transparent,
        focusedIndicatorColor = Color.Transparent,
        unfocusedIndicatorColor = Color.Transparent,
        focusedTextColor = fg,
        unfocusedTextColor = fg,
        cursorColor = fg,
        focusedPlaceholderColor = fg.copy(alpha = 0.5f),
        unfocusedPlaceholderColor = fg.copy(alpha = 0.5f)
    )

    Scaffold(
        containerColor = bg,
        contentColor = fg,
        topBar = {
            TopAppBar(
                title = {},
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = null)
                    }
                },
                actions = {
                    IconButton(onClick = { pinned = !pinned }) {
                        Icon(
                            Icons.Default.Star, contentDescription = null,
                            tint = if (pinned) Color(0xFFF9A825) else fg.copy(alpha = 0.5f)
                        )
                    }
                    IconButton(onClick = { share() }) {
                        Icon(Icons.Default.Share, contentDescription = null)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color.Transparent,
                    scrolledContainerColor = Color.Transparent,
                    navigationIconContentColor = fg,
                    actionIconContentColor = fg
                )
            )
        }
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize().verticalScroll(rememberScrollState())) {
            TextField(
                value = title,
                onValueChange = { title = it },
                modifier = Modifier.fillMaxWidth(),
                placeholder = { Text(tr("Title", "শিরোনাম"), style = MaterialTheme.typography.headlineSmall) },
                textStyle = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Bold),
                colors = fieldColors
            )
            TextField(
                value = content,
                onValueChange = { content = it },
                modifier = Modifier.fillMaxWidth().heightIn(min = 260.dp),
                placeholder = { Text(tr("Write here…", "এখানে লিখুন…")) },
                colors = fieldColors
            )
            TextField(
                value = tags,
                onValueChange = { tags = it },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                placeholder = { Text(tr("Tags (comma separated)", "ট্যাগ (কমা দিয়ে আলাদা করুন)")) },
                colors = fieldColors
            )
            Column(
                Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(tr("Category", "ক্যাটাগরি"), style = MaterialTheme.typography.labelLarge)
                Row(
                    Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    FilterChip(
                        selected = categoryId == null,
                        onClick = { categoryId = null },
                        label = { Text(tr("None", "কোনোটি নয়")) }
                    )
                    cats.forEach { c ->
                        FilterChip(
                            selected = categoryId == c.id,
                            onClick = { categoryId = c.id },
                            label = { Text(c.name) }
                        )
                    }
                }
                Text(tr("Color", "রঙ"), style = MaterialTheme.typography.labelLarge)
                ColorRow(selected = color, accent = false, onPick = { color = it })
                TextButton(onClick = {
                    trashed = true
                    vm.moveToTrash(base.id)
                    onBack()
                }) {
                    Icon(Icons.Default.Delete, contentDescription = null, tint = MaterialTheme.colorScheme.error)
                    Spacer(Modifier.width(8.dp))
                    Text(tr("Move to trash", "ট্র্যাশে পাঠান"), color = MaterialTheme.colorScheme.error)
                }
            }
        }
    }
}
