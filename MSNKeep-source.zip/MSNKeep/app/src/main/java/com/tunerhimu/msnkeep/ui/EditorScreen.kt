@file:OptIn(ExperimentalMaterial3Api::class)

package com.tunerhimu.msnkeep.ui

import android.content.Intent
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.tunerhimu.msnkeep.MainViewModel
import com.tunerhimu.msnkeep.data.Attachment
import com.tunerhimu.msnkeep.data.Note
import com.tunerhimu.msnkeep.data.NoteVersion
import com.tunerhimu.msnkeep.export.Exporter
import com.tunerhimu.msnkeep.util.Files
import kotlinx.coroutines.delay
import java.io.File

@Composable
fun EditorScreen(vm: MainViewModel, noteId: Long, onBack: () -> Unit) {
    var base by remember { mutableStateOf<Note?>(null) }
    LaunchedEffect(noteId) { base = vm.load(noteId) }
    val loaded = base
    if (loaded == null) {
        Box(Modifier.fillMaxSize())
    } else {
        EditorContent(vm, loaded, onBack)
    }
}

private fun formatLabel(f: Exporter.Format): String = when (f) {
    Exporter.Format.TXT -> "Plain text (.txt)"
    Exporter.Format.MD -> "Markdown (.md)"
    Exporter.Format.HTML -> "Web page (.html)"
    Exporter.Format.DOC -> "Word document (.doc)"
    Exporter.Format.PDF -> "PDF document (.pdf)"
}

@Composable
private fun EditorContent(vm: MainViewModel, base: Note, onBack: () -> Unit) {
    var title by remember { mutableStateOf(base.title) }
    var content by remember { mutableStateOf(base.content) }
    var tags by remember { mutableStateOf(base.tags) }
    var color by remember { mutableStateOf(base.colorIndex) }
    var pinned by remember { mutableStateOf(base.pinned) }
    var categoryId by remember { mutableStateOf(base.categoryId) }
    var trashed by remember { mutableStateOf(false) }
    var showMenu by remember { mutableStateOf(false) }
    var showHistory by remember { mutableStateOf(false) }
    var showExport by remember { mutableStateOf(false) }

    val cats by vm.categories.collectAsStateWithLifecycle()
    val versions by remember(base.id) { vm.versions(base.id) }
        .collectAsStateWithLifecycle(initialValue = emptyList<NoteVersion>())
    val atts by remember(base.id) { vm.attachmentsOf(base.id) }
        .collectAsStateWithLifecycle(initialValue = emptyList<Attachment>())
    val ctx = LocalContext.current
    val bn = LocalBn.current

    val pickImage = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) vm.addAttachment(base.id, uri)
    }
    val pickFile = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) vm.addAttachment(base.id, uri)
    }

    fun snapshot(): Note = base.copy(
        title = title, content = content, tags = tags,
        colorIndex = color, pinned = pinned, categoryId = categoryId
    )

    // Auto-save shortly after the last change
    LaunchedEffect(title, content, tags, color, pinned, categoryId) {
        delay(500)
        val s = snapshot()
        if (s != base && !trashed) vm.save(s)
    }

    // On leaving: keep the opening state as an edit-history version, save, or discard an empty new note
    DisposableEffect(Unit) {
        onDispose {
            if (!trashed) {
                val s = snapshot()
                val wasEmpty = base.title.isBlank() && base.content.isBlank()
                if (s.title.isBlank() && s.content.isBlank() && wasEmpty) {
                    vm.deleteForever(s.id)
                } else {
                    if (s.title != base.title || s.content != base.content) {
                        vm.recordVersion(base.id, base.title, base.content)
                    }
                    if (s != base) vm.save(s)
                }
            }
        }
    }

    fun shareText() {
        val send = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_SUBJECT, title)
            putExtra(Intent.EXTRA_TEXT, if (title.isBlank()) content else "$title\n\n$content")
        }
        ctx.startActivity(Intent.createChooser(send, null))
    }

    fun exportAs(f: Exporter.Format) {
        try {
            val file = Exporter.write(ctx, snapshot(), f)
            Files.share(ctx, file, f.mime)
        } catch (e: Exception) {
            Toast.makeText(ctx, "Export failed", Toast.LENGTH_SHORT).show()
        }
    }

    val bg = if (color == 0) MaterialTheme.colorScheme.background else noteBg(color)
    val fg = if (color == 0) MaterialTheme.colorScheme.onBackground else noteFg(color)
    val fieldColors = TextFieldDefaults.colors(
        focusedContainerColor = Color.Transparent,
        unfocusedContainerColor = Color.Transparent,
        focusedIndicatorColor = Color.Transparent,
        unfocusedIndicatorColor = Color.Transparent,
        focusedTextColor = fg,
        unfocusedTextColor = fg,
        cursorColor = fg,
        focusedPlaceholderColor = fg.copy(alpha = 0.5f),
        unfocusedPlaceholderColor = fg.copy(alpha = 0.5f)
    )

    Scaffold(
        containerColor = bg,
        contentColor = fg,
        topBar = {
            TopAppBar(
                title = {},
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = null)
                    }
                },
                actions = {
                    IconButton(onClick = { pinned = !pinned }) {
                        Icon(
                            Icons.Default.Star, contentDescription = null,
                            tint = if (pinned) Color(0xFFF9A825) else fg.copy(alpha = 0.5f)
                        )
                    }
                    Box {
                        IconButton(onClick = { showMenu = true }) {
                            Icon(Icons.Default.MoreVert, contentDescription = null)
                        }
                        DropdownMenu(expanded = showMenu, onDismissRequest = { showMenu = false }) {
                            DropdownMenuItem(
                                text = { Text(tr("Add photo", "ছবি যোগ করুন")) },
                                onClick = { showMenu = false; pickImage.launch("image/*") }
                            )
                            DropdownMenuItem(
                                text = { Text(tr("Attach file", "ফাইল যোগ করুন")) },
                                onClick = { showMenu = false; pickFile.launch("*/*") }
                            )
                            DropdownMenuItem(
                                text = { Text(tr("Edit history", "এডিট হিস্টোরি")) },
                                onClick = { showMenu = false; showHistory = true }
                            )
                            DropdownMenuItem(
                                text = { Text(tr("Export & share", "এক্সপোর্ট ও শেয়ার")) },
                                onClick = { showMenu = false; showExport = true }
                            )
                            DropdownMenuItem(
                                text = {
                                    Text(tr("Move to trash", "ট্র্যাশে পাঠান"), color = MaterialTheme.colorScheme.error)
                                },
                                onClick = {
                                    showMenu = false
                                    trashed = true
                                    vm.moveToTrash(base.id)
                                    onBack()
                                }
                            )
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color.Transparent,
                    scrolledContainerColor = Color.Transparent,
                    navigationIconContentColor = fg,
                    actionIconContentColor = fg
                )
            )
        }
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize().verticalScroll(rememberScrollState())) {
            TextField(
                value = title,
                onValueChange = { title = it },
                modifier = Modifier.fillMaxWidth(),
                placeholder = { Text(tr("Title", "শিরোনাম"), style = MaterialTheme.typography.headlineSmall) },
                textStyle = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Bold),
                colors = fieldColors
            )
            TextField(
                value = content,
                onValueChange = { content = it },
                modifier = Modifier.fillMaxWidth().heightIn(min = 240.dp),
                placeholder = { Text(tr("Write here…", "এখানে লিখুন…")) },
                colors = fieldColors
            )
            if (atts.isNotEmpty()) {
                Row(
                    Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    for (a in atts) {
                        key(a.id) {
                            if (a.mime.startsWith("image/")) {
                                Box(
                                    Modifier.size(104.dp).clip(RoundedCornerShape(16.dp))
                                        .background(fg.copy(alpha = 0.08f))
                                        .clickable { Files.open(ctx, File(a.path), a.mime) }
                                ) {
                                    val bmp = remember(a.path) { Files.decodeThumb(a.path, 220) }
                                    if (bmp != null) {
                                        Image(
                                            bitmap = bmp.asImageBitmap(),
                                            contentDescription = a.name,
                                            contentScale = ContentScale.Crop,
                                            modifier = Modifier.fillMaxSize()
                                        )
                                    }
                                    IconButton(
                                        onClick = { vm.removeAttachment(a) },
                                        modifier = Modifier.align(Alignment.TopEnd).size(30.dp)
                                    ) {
                                        Icon(Icons.Default.Close, contentDescription = null, tint = Color.White)
                                    }
                                }
                            } else {
                                Row(
                                    Modifier.clip(RoundedCornerShape(14.dp))
                                        .background(fg.copy(alpha = 0.10f))
                                        .clickable { Files.open(ctx, File(a.path), a.mime) }
                                        .padding(start = 14.dp, top = 6.dp, bottom = 6.dp, end = 4.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        a.name, maxLines = 1, overflow = TextOverflow.Ellipsis,
                                        modifier = Modifier.widthIn(max = 170.dp)
                                    )
                                    IconButton(onClick = { vm.removeAttachment(a) }, modifier = Modifier.size(30.dp)) {
                                        Icon(Icons.Default.Close, contentDescription = null)
                                    }
                                }
                            }
                        }
                    }
                }
            }
            TextField(
                value = tags,
                onValueChange = { tags = it },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                placeholder = { Text(tr("Tags (comma separated)", "ট্যাগ (কমা দিয়ে আলাদা করুন)")) },
                colors = fieldColors
            )
            Column(
                Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(tr("Category", "ক্যাটাগরি"), style = MaterialTheme.typography.labelLarge)
                Row(
                    Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    FilterChip(
                        selected = categoryId == null,
                        onClick = { categoryId = null },
                        label = { Text(tr("None", "কোনোটি নয়")) }
                    )
                    cats.forEach { c ->
                        FilterChip(
                            selected = categoryId == c.id,
                            onClick = { categoryId = c.id },
                            label = { Text(c.name) }
                        )
                    }
                }
                Text(tr("Color", "রঙ"), style = MaterialTheme.typography.labelLarge)
                ColorRow(selected = color, accent = false, onPick = { color = it })
            }
        }
    }

    if (showHistory) {
        AlertDialog(
            onDismissRequest = { showHistory = false },
            title = { Text(tr("Edit history", "এডিট হিস্টোরি")) },
            text = {
                if (versions.isEmpty()) {
                    Text(
                        tr(
                            "No earlier versions yet. A version is saved each time you edit this note.",
                            "এখনো কোনো আগের সংস্করণ নেই। নোট এডিট করলেই আগের অবস্থা এখানে জমা হবে।"
                        )
                    )
                } else {
                    LazyColumn(Modifier.heightIn(max = 380.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        items(versions, key = { it.id }) { v ->
                            Column(
                                Modifier.fillMaxWidth()
                                    .clip(RoundedCornerShape(14.dp))
                                    .background(MaterialTheme.colorScheme.surfaceVariant)
                                    .padding(12.dp)
                            ) {
                                Text(
                                    fmtDate(v.savedAt, bn) + " • " + fmtTime(v.savedAt, bn),
                                    style = MaterialTheme.typography.labelMedium,
                                    color = MaterialTheme.colorScheme.primary
                                )
                                Text(
                                    v.title.ifBlank { tr("Untitled", "শিরোনামহীন") },
                                    fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    v.content, maxLines = 3, overflow = TextOverflow.Ellipsis,
                                    style = MaterialTheme.typography.bodySmall
                                )
                                TextButton(onClick = {
                                    vm.recordVersion(base.id, title, content)
                                    title = v.title
                                    content = v.content
                                    showHistory = false
                                }) { Text(tr("Restore this version", "এই সংস্করণ ফিরিয়ে আনুন")) }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showHistory = false }) { Text(tr("Close", "বন্ধ")) }
            }
        )
    }

    if (showExport) {
        AlertDialog(
            onDismissRequest = { showExport = false },
            title = { Text(tr("Export & share", "এক্সপোর্ট ও শেয়ার")) },
            text = {
                Column {
                    TextButton(onClick = { showExport = false; shareText() }, modifier = Modifier.fillMaxWidth()) {
                        Text(tr("Share as text", "টেক্সট হিসেবে শেয়ার"), modifier = Modifier.fillMaxWidth())
                    }
                    for (f in Exporter.Format.values()) {
                        TextButton(onClick = { showExport = false; exportAs(f) }, modifier = Modifier.fillMaxWidth()) {
                            Text(formatLabel(f), modifier = Modifier.fillMaxWidth())
                        }
                    }
                    Spacer(Modifier.width(1.dp))
                    Text(
                        tr(
                            "After choosing a format, pick Drive, Files, WhatsApp, Email… to save or send it.",
                            "ফরম্যাট বাছাইয়ের পর Drive, Files, WhatsApp, Email ইত্যাদি বেছে সেভ বা পাঠান।"
                        ),
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = { showExport = false }) { Text(tr("Close", "বন্ধ")) }
            }
        )
    }
}
