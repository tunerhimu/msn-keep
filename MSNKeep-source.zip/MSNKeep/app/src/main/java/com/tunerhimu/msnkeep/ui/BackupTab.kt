@file:OptIn(ExperimentalMaterial3Api::class)

package com.tunerhimu.msnkeep.ui

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.tunerhimu.msnkeep.MainViewModel
import com.tunerhimu.msnkeep.backup.BackupManager
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun BackupTab(vm: MainViewModel) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var status by remember { mutableStateOf("") }
    var pendingRestore by remember { mutableStateOf<Uri?>(null) }

    val msgBackupOk = tr("Backup saved successfully.", "ব্যাকআপ সফলভাবে সেভ হয়েছে।")
    val msgBackupFail = tr("Backup failed. Please try again.", "ব্যাকআপ ব্যর্থ হয়েছে। আবার চেষ্টা করুন।")
    val msgRestoreOk = tr("Restore complete. Your data is back.", "রিস্টোর সম্পন্ন। আপনার ডাটা ফিরে এসেছে।")
    val msgRestoreFail = tr(
        "This file could not be restored. Is it an MSN Keep backup?",
        "এই ফাইল রিস্টোর করা যায়নি। এটা কি MSN Keep-এর ব্যাকআপ ফাইল?"
    )
    val msgImported = tr("Imported. Check your notes list.", "ইমপোর্ট হয়েছে। নোটের তালিকা দেখুন।")

    val createLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/zip")
    ) { uri ->
        if (uri != null) {
            scope.launch {
                status = if (BackupManager.export(ctx, uri)) msgBackupOk else msgBackupFail
            }
        }
    }
    val restoreLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri -> if (uri != null) pendingRestore = uri }
    val importLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri ->
        if (uri != null) {
            vm.importTextNote(uri)
            status = msgImported
        }
    }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(tr("Backup & Restore", "ব্যাকআপ ও রিস্টোর"), style = MaterialTheme.typography.headlineSmall)

        Card(
            modifier = Modifier.fillMaxWidth(),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
        ) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(tr("Back up to your Google account", "গুগল একাউন্টে ব্যাকআপ"), style = MaterialTheme.typography.titleMedium)
                Text(
                    tr(
                        "Tap the button, then in the file picker open the menu (☰) and choose Google Drive. The backup file is stored in your Google account. It includes notes, tasks, events, attachments and edit history.",
                        "বোতামে চাপ দিন, তারপর ফাইল বাছাইয়ের পর্দায় মেনু (☰) খুলে Google Drive বেছে নিন। ব্যাকআপ ফাইল আপনার গুগল একাউন্টে জমা হবে। এতে নোট, কাজ, ইভেন্ট, অ্যাটাচমেন্ট ও এডিট হিস্টোরি থাকে।"
                    ),
                    style = MaterialTheme.typography.bodySmall
                )
                Button(
                    onClick = {
                        val stamp = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
                        createLauncher.launch("MSN-Keep-backup-$stamp.zip")
                    },
                    modifier = Modifier.fillMaxWidth()
                ) { Text(tr("Create backup", "ব্যাকআপ তৈরি করুন")) }
                OutlinedButton(
                    onClick = { restoreLauncher.launch(arrayOf("*/*")) },
                    modifier = Modifier.fillMaxWidth()
                ) { Text(tr("Restore from backup (Drive or phone)", "ব্যাকআপ থেকে রিস্টোর (Drive বা ফোন)")) }
            }
        }

        Card(
            modifier = Modifier.fillMaxWidth(),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
        ) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(tr("Manual export & import", "ম্যানুয়াল এক্সপোর্ট ও ইমপোর্ট"), style = MaterialTheme.typography.titleMedium)
                Text(
                    tr(
                        "The same backup file can be saved to your phone (for example in Downloads) and restored later. To export a single note as TXT, Markdown, HTML, Word or PDF, open the note and use the ⋮ menu → Export & share.",
                        "একই ব্যাকআপ ফাইল ফোনেও (যেমন Downloads-এ) সেভ করে পরে রিস্টোর করা যায়। একটি নোট TXT, Markdown, HTML, Word বা PDF করতে নোট খুলে ⋮ মেনু → এক্সপোর্ট ও শেয়ার ব্যবহার করুন।"
                    ),
                    style = MaterialTheme.typography.bodySmall
                )
                OutlinedButton(
                    onClick = { importLauncher.launch("text/*") },
                    modifier = Modifier.fillMaxWidth()
                ) { Text(tr("Import a .txt / .md file as a note", ".txt / .md ফাইল নোট হিসেবে ইমপোর্ট")) }
            }
        }

        if (status.isNotEmpty()) {
            Text(status, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.primary)
        }
    }

    val restoreUri = pendingRestore
    if (restoreUri != null) {
        AlertDialog(
            onDismissRequest = { pendingRestore = null },
            title = { Text(tr("Restore this backup?", "এই ব্যাকআপ রিস্টোর করবেন?")) },
            text = {
                Text(
                    tr(
                        "This will replace ALL current notes, tasks and events on this phone with the ones in the backup.",
                        "এতে এই ফোনের সব বর্তমান নোট, কাজ ও ইভেন্ট মুছে ব্যাকআপের ডাটা বসবে।"
                    )
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    pendingRestore = null
                    scope.launch {
                        status = if (BackupManager.restore(ctx, restoreUri)) msgRestoreOk else msgRestoreFail
                    }
                }) { Text(tr("Restore", "রিস্টোর"), color = MaterialTheme.colorScheme.error) }
            },
            dismissButton = {
                TextButton(onClick = { pendingRestore = null }) { Text(tr("Cancel", "বাতিল")) }
            }
        )
    }
}
