package com.tunerhimu.msnkeep

import android.app.Application
import android.net.Uri
import androidx.datastore.preferences.core.edit
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.tunerhimu.msnkeep.data.AppDatabase
import com.tunerhimu.msnkeep.data.Attachment
import com.tunerhimu.msnkeep.data.Category
import com.tunerhimu.msnkeep.data.NoteVersion
import com.tunerhimu.msnkeep.util.Files
import java.io.File
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import com.tunerhimu.msnkeep.data.Event
import com.tunerhimu.msnkeep.data.Task
import com.tunerhimu.msnkeep.reminder.ReminderScheduler
import com.tunerhimu.msnkeep.data.Note
import com.tunerhimu.msnkeep.data.SettingKeys
import com.tunerhimu.msnkeep.data.dataStore
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val dao = AppDatabase.get(app).dao()
    private val store = app.dataStore

    val query = MutableStateFlow("")
    val categoryFilter = MutableStateFlow<Long?>(null)

    val categories: StateFlow<List<Category>> =
        dao.categories().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val trashedNotes: StateFlow<List<Note>> =
        dao.trashedNotes().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allNotes: StateFlow<List<Note>> =
        dao.activeNotes().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val notes: StateFlow<List<Note>> =
        combine(allNotes, query, categoryFilter) { list, q, cat ->
            list.filter { n ->
                (n.title.isNotBlank() || n.content.isNotBlank()) &&
                    (cat == null || n.categoryId == cat) &&
                    (q.isBlank() ||
                        n.title.contains(q, ignoreCase = true) ||
                        n.content.contains(q, ignoreCase = true) ||
                        n.tags.contains(q, ignoreCase = true))
            }
        }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val themeMode: StateFlow<Int> =
        store.data.map { it[SettingKeys.THEME] ?: 0 }.stateIn(viewModelScope, SharingStarted.Eagerly, 0)
    val bengali: StateFlow<Boolean> =
        store.data.map { it[SettingKeys.BN] ?: true }.stateIn(viewModelScope, SharingStarted.Eagerly, true)
    val grid: StateFlow<Boolean> =
        store.data.map { it[SettingKeys.GRID] ?: true }.stateIn(viewModelScope, SharingStarted.Eagerly, true)

    fun setTheme(value: Int) {
        viewModelScope.launch { store.edit { it[SettingKeys.THEME] = value } }
    }

    fun setBengali(value: Boolean) {
        viewModelScope.launch { store.edit { it[SettingKeys.BN] = value } }
    }

    fun setGrid(value: Boolean) {
        viewModelScope.launch { store.edit { it[SettingKeys.GRID] = value } }
    }

    suspend fun createNote(): Long = dao.upsert(Note(categoryId = categoryFilter.value))

    suspend fun load(id: Long): Note? = dao.getNote(id)

    fun save(note: Note) {
        viewModelScope.launch { dao.upsert(note.copy(updatedAt = System.currentTimeMillis())) }
    }

    fun moveToTrash(id: Long) {
        viewModelScope.launch { dao.setDeleted(id, true, System.currentTimeMillis()) }
    }

    fun restore(id: Long) {
        viewModelScope.launch { dao.setDeleted(id, false, System.currentTimeMillis()) }
    }

    private suspend fun purge(id: Long) {
        for (a in dao.attachmentsOnce(id)) File(a.path).delete()
        dao.deleteAttachmentsOf(id)
        dao.deleteVersionsOf(id)
        dao.deleteForever(id)
    }

    fun deleteForever(id: Long) {
        viewModelScope.launch { purge(id) }
    }

    fun emptyTrash() {
        viewModelScope.launch {
            for (n in trashedNotes.value) purge(n.id)
        }
    }

    fun addCategory(name: String, colorIndex: Int) {
        viewModelScope.launch { dao.insertCategory(Category(name = name, colorIndex = colorIndex)) }
    }

    fun updateCategory(category: Category) {
        viewModelScope.launch { dao.updateCategory(category) }
    }

    fun deleteCategory(category: Category) {
        viewModelScope.launch {
            dao.clearCategory(category.id)
            dao.deleteCategory(category)
            if (categoryFilter.value == category.id) categoryFilter.value = null
        }
    }

    private val appCtx: Application = app

    val tasks: StateFlow<List<Task>> =
        dao.tasks().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val events: StateFlow<List<Event>> =
        dao.events().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    suspend fun loadTask(id: Long): Task? = dao.getTask(id)

    suspend fun loadEvent(id: Long): Event? = dao.getEvent(id)

    fun saveTask(task: Task) {
        viewModelScope.launch {
            val id = dao.upsertTask(task)
            ReminderScheduler.scheduleTask(appCtx, task.copy(id = id))
        }
    }

    fun deleteTask(id: Long) {
        viewModelScope.launch {
            ReminderScheduler.cancelTask(appCtx, id)
            dao.deleteTask(id)
        }
    }

    fun toggleTask(task: Task) {
        viewModelScope.launch { ReminderScheduler.toggleDone(appCtx, task) }
    }

    fun saveEvent(event: Event) {
        viewModelScope.launch {
            val id = dao.upsertEvent(event)
            ReminderScheduler.scheduleEvent(appCtx, event.copy(id = id))
        }
    }

    fun deleteEvent(id: Long) {
        viewModelScope.launch {
            ReminderScheduler.cancelEvent(appCtx, id)
            dao.deleteEvent(id)
        }
    }

    fun versions(noteId: Long): Flow<List<NoteVersion>> = dao.versions(noteId)

    fun attachmentsOf(noteId: Long): Flow<List<Attachment>> = dao.attachments(noteId)

    fun recordVersion(noteId: Long, title: String, content: String) {
        if (title.isBlank() && content.isBlank()) return
        viewModelScope.launch {
            val existing = dao.versionsOnce(noteId)
            val last = existing.firstOrNull()
            if (last != null && last.title == title && last.content == content) return@launch
            dao.insertVersion(NoteVersion(noteId = noteId, title = title, content = content))
            for (old in existing.drop(29)) dao.deleteVersion(old.id)
        }
    }

    fun addAttachment(noteId: Long, uri: Uri) {
        viewModelScope.launch(Dispatchers.IO) {
            val a = Files.copyIn(appCtx, noteId, uri)
            if (a != null) dao.insertAttachment(a)
        }
    }

    fun removeAttachment(a: Attachment) {
        viewModelScope.launch(Dispatchers.IO) {
            File(a.path).delete()
            dao.deleteAttachment(a.id)
        }
    }

    fun importTextNote(uri: Uri) {
        viewModelScope.launch(Dispatchers.IO) {
            val text = try {
                appCtx.contentResolver.openInputStream(uri)?.use { it.readBytes().toString(Charsets.UTF_8) }
            } catch (e: Exception) {
                null
            }
            if (text != null) {
                val name = Files.displayName(appCtx, uri).substringBeforeLast('.')
                dao.upsert(Note(title = name, content = text))
            }
        }
    }
}
