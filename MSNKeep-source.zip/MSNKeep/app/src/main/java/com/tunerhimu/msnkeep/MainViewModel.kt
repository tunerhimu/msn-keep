package com.tunerhimu.msnkeep

import android.app.Application
import androidx.datastore.preferences.core.edit
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.tunerhimu.msnkeep.data.AppDatabase
import com.tunerhimu.msnkeep.data.Category
import com.tunerhimu.msnkeep.data.Note
import com.tunerhimu.msnkeep.data.SettingKeys
import com.tunerhimu.msnkeep.data.dataStore
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val dao = AppDatabase.get(app).dao()
    private val store = app.dataStore

    val query = MutableStateFlow("")
    val categoryFilter = MutableStateFlow<Long?>(null)

    val categories: StateFlow<List<Category>> =
        dao.categories().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val trashedNotes: StateFlow<List<Note>> =
        dao.trashedNotes().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allNotes: StateFlow<List<Note>> =
        dao.activeNotes().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val notes: StateFlow<List<Note>> =
        combine(allNotes, query, categoryFilter) { list, q, cat ->
            list.filter { n ->
                (n.title.isNotBlank() || n.content.isNotBlank()) &&
                    (cat == null || n.categoryId == cat) &&
                    (q.isBlank() ||
                        n.title.contains(q, ignoreCase = true) ||
                        n.content.contains(q, ignoreCase = true) ||
                        n.tags.contains(q, ignoreCase = true))
            }
        }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val themeMode: StateFlow<Int> =
        store.data.map { it[SettingKeys.THEME] ?: 0 }.stateIn(viewModelScope, SharingStarted.Eagerly, 0)
    val bengali: StateFlow<Boolean> =
        store.data.map { it[SettingKeys.BN] ?: true }.stateIn(viewModelScope, SharingStarted.Eagerly, true)
    val grid: StateFlow<Boolean> =
        store.data.map { it[SettingKeys.GRID] ?: true }.stateIn(viewModelScope, SharingStarted.Eagerly, true)

    fun setTheme(value: Int) {
        viewModelScope.launch { store.edit { it[SettingKeys.THEME] = value } }
    }

    fun setBengali(value: Boolean) {
        viewModelScope.launch { store.edit { it[SettingKeys.BN] = value } }
    }

    fun setGrid(value: Boolean) {
        viewModelScope.launch { store.edit { it[SettingKeys.GRID] = value } }
    }

    suspend fun createNote(): Long = dao.upsert(Note(categoryId = categoryFilter.value))

    suspend fun load(id: Long): Note? = dao.getNote(id)

    fun save(note: Note) {
        viewModelScope.launch { dao.upsert(note.copy(updatedAt = System.currentTimeMillis())) }
    }

    fun moveToTrash(id: Long) {
        viewModelScope.launch { dao.setDeleted(id, true, System.currentTimeMillis()) }
    }

    fun restore(id: Long) {
        viewModelScope.launch { dao.setDeleted(id, false, System.currentTimeMillis()) }
    }

    fun deleteForever(id: Long) {
        viewModelScope.launch { dao.deleteForever(id) }
    }

    fun emptyTrash() {
        viewModelScope.launch { dao.emptyTrash() }
    }

    fun addCategory(name: String, colorIndex: Int) {
        viewModelScope.launch { dao.insertCategory(Category(name = name, colorIndex = colorIndex)) }
    }

    fun updateCategory(category: Category) {
        viewModelScope.launch { dao.updateCategory(category) }
    }

    fun deleteCategory(category: Category) {
        viewModelScope.launch {
            dao.clearCategory(category.id)
            dao.deleteCategory(category)
            if (categoryFilter.value == category.id) categoryFilter.value = null
        }
    }
}
